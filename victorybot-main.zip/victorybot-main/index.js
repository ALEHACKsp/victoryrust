const Discord = require("discord.js");
const Enmap = require("enmap");
const glob = require("glob");
const fs = require("fs");

const client = new Discord.Client();
const config = require('./config.json');
client.commands = new Enmap();

glob("commands/**/*.js", function (err, files) {
  // Change every name file to directory
  files = files.map((item) => {
    return "./" + item;
  });

  // Add to client emit
  files.forEach((file) => {
    const command = require(file),
      commandName = file.split("/")[3].split(".")[0];

    console.log("command(added): " + commandName);
    client.commands.set(commandName, command);
  });
});

glob("events/**/*.js", function (err, files) {
  // Change every name file to directory
  files = files.map((item) => {
    return "./" + item;
  });

  // Add to client emit
  files.forEach((file) => {
    const event = require(file),
      eventName = file.split("/")[3].split(".")[0];
    console.log("event(added): " + eventName);
    client.on(eventName, event.bind(null, client));
  });
});

client.login(config.token);

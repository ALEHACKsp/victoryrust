exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR") && !message.member.roles.cache.find((role) => role.name === "Confirmer")) return;
  
  if (!message.mentions.members.first()) return message.reply("You should tag somebody first!");

  let will_be_confirmed = message.mentions.members.first();
  let confirm_role = message.guild.roles.cache.find((role) => role.name === "Approved");
  let not_confirmed_role = message.guild.roles.cache.find((role) => role.name === "Not Approved");

  if (will_be_confirmed.roles.cache.find((role) => role.name === "Approved")) return message.reply(`User named <@${will_be_confirmed.id}> is already approved.`);
  await will_be_confirmed.roles.add(confirm_role);
  if (will_be_confirmed.roles.cache.find((role) => role.name === "Not Approved")) await will_be_confirmed.roles.remove(not_confirmed_role);
  return await message.reply(`You successfully approved <@${will_be_confirmed.id}>!`);
};

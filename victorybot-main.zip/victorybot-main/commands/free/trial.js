const fs = require("fs");
const axios = require("axios");
const querystring = require('querystring');
const Captcha = require('../../helpers/Captcha');

const CaptchaMap = new Map();
const config = require('../../config.json');

const URL = "https://victoryrust.com";
const API_KEY = "create_trial_xxoo";
const MAIN_GUILD = "866750906624507919";

exports.run = async (client, message, args) => {

  if (message.channel.type !== "dm") return message.channel.send("You can only use this command **in Direct Messages!**");
  if (CaptchaMap.get(message.author.id || message.member.id)) return message.channel.send("You are **already** doing a captcha. Please continue with it.");
  if (Date.now() - client.guilds.cache.get(MAIN_GUILD).members.cache.get(message.author.id).user.createdAt < 1000 * 60 * 60 * 24 * 5) return message.channel.send("Your account is **too new** to try our trial. Please try again later.");
  if (!client.guilds.cache.get(MAIN_GUILD).members.cache.get(message.author.id).roles.cache.find((r) => r.name === "Approved")) return message.channel.send(`You have to **get approved first** to **use** this **command**. You can get approved from **photos** <#${client.guilds.cache.get(MAIN_GUILD).channels.cache.find(channel => channel.name == "photos").id}> channel.\nIf you **dont know how to get approved**, please check **requirements** <#${client.guilds.cache.get(MAIN_GUILD).channels.cache.find(channel => channel.name == "requirements").id}> channel. Thank you! :smile:`)

  if (!CaptchaMap.get(message.author.id)) CaptchaMap.set(message.author.id || message.member.id, 0);

  const captcha = await Captcha();
  try {
    const msg = await message.channel.send('You have **20 seconds** to solve our captcha!\nIt is **case-sensitive** so please write exactly what it says.', {
      files: [{
        attachment: `./captchas/${captcha}.png`,
        name: `${captcha}.png`
      }]
    });

    try {
      const filter = m => {
        if (m.author.bot) return false;
        if (m.author.id === message.author.id && m.content === captcha) {
          return true;
        } else {
          CaptchaMap.set(message.author.id || message.member.id, CaptchaMap.get(message.author.id || message.member.id) + 1);
          if (m.content.startsWith(config.prefix)) return;
          if (CaptchaMap.get(message.author.id) >= 3) {
            return false;
          } else if (CaptchaMap.get(message.author.id) == 2) {
            m.channel.send('You entered the captcha **incorrectly.** Please try again.\n\nI **will not** give you any **status text** because of spamming purposes.');
            return false;
          } else {
            m.channel.send('You entered the captcha **incorrectly.** Please try again.');
            return false;
          }
        }
      };

      const response = await msg.channel.awaitMessages(filter, { max: 1, time: 20000, errors: ['time'] });

      if (response) {
        await msg.channel.send('**Success!** Now, we are preparing trial for you.');
        CaptchaMap.delete(message.author.id || message.member.id);
        fs.unlinkSync(`./captchas/${captcha}.png`);

        const res = await axios.post(`${URL}/api/create.php`, querystring.stringify({
          id: message.author.id,
          key: API_KEY
        }), {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded"
          }
        });


        if (!res.data.key) {
          return await message.channel.send(`You **already** tried our vFree.\nYou **cant get** another key, we're sorry :(`);
        };

        await message.channel.send(`Heres your **trial key:**\n\` ${res.data.key} \`\n\n**Quick FAQ:**\n- You cant get another key, it'll be locked to your hwid.\n- This key expires in 3 days.\n- You cant trade or sell this key.\n\nYou can get it from: https://victoryrust.com/free.php\n**Have fun! :wink:**`)
      };

    } catch (err) {
      await msg.channel.send('You **did not** solve the captcha **correctly on time.**');
      CaptchaMap.delete(message.author.id || message.member.id)
      fs.unlinkSync(`./captchas/${captcha}.png`);
    };

  } catch (e) {
    console.log(e);
  }
};

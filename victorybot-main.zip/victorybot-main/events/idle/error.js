module.exports = async (client, error) => {
  console.error("error -> " + error);
};
module.exports = async (client, warn) => {
  console.warn("warn -> " + warn);
};
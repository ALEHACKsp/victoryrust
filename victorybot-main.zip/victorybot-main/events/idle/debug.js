module.exports = async (client, debug) => {
  console.warn("debug -> " + debug);
};
const Cleaner = require('../../helpers/Cleaner');
const utils = new Cleaner(true);

module.exports = async (client) => {
  const time = 1000 * 60 * 20;
  const main = {
    id: "866750906624507919",
    obj: [
      {
        channelName: "chat",
        time: time,
        afterMessage: ":revolving_hearts: Chat for **\"Approved\"** users. Please read all.\n\nYou can still get help from our staff members if you\nneed have any problems about our discord bot/system.\n\nYou can tag a online staff member if\nyou dont get any help by 5 minutes.\n\nFor security policies, we clear our chat every 20 minutes.\nThank you for your patience.",
        afterPin: true,
      },
      {
        channelName: "help",
        time: time,
        afterMessage: ":heart_on_fire: Help section for **\"Not Approved\"** users. Please read all.\n\nYou can tag a online staff member if\nyou dont get any help by 5 minutes.\n\nFor security policies, we clear our chat every 20 minutes.\nThank you for your patience.",
        afterPin: true,
      },
      {
        channelName: "photos",
        time: time,
        afterMessage: ":camera: You know what to do here. If you dont, check out **requirements** channel.",
        afterPin: true
      },
      {
        channelName: "requirements",
        time: time,
        afterMessage: ":camera: How to get vFree **(video)**: <https://youtu.be/6N8SJKuBaGw>\n\n:mailbox_with_mail: How to get vFree **(text)**:\n\nFor vFree approval, you need to complete few steps:\n\n**1)** Subscribe to our youtube channels:\n<https://www.youtube.com/vexdys>\n<https://www.youtube.com/channel/UCI-G0I-IfpMoZIjPzn1iVWA>\n<https://www.youtube.com/channel/UCGSNcGRI_fgEbcYt6V_OI5w>\n<https://www.youtube.com/channel/UCuLj-5oR2JzuxpbAALKosrg>\n<https://www.youtube.com/channel/UCXJmfhOYj5UUWdkx1KOJfNg>\n\n**2)** Like the latest video of our channels.\n**3)** Complete these steps and take a screenshot about it. Send that screenshot to **photos** channel.\n**4)** When you are done these steps, we will add you a new role on discord so you can use \`.trial\` command in our bot's DM for generating your unique key.\n\nDo not forget to **open privacy settings in guild!**\nhttps://cdn.discordapp.com/attachments/872475331716612136/874690000673968129/open-privacy.gif\n\n**Good luck!**"
      }
    ]
  };

  utils.channelClear(client, main.id, main.obj)
  console.log(client.user.tag);
};
const Jimp = require('jimp');

module.exports = async function createCaptcha() {
  const captcha = Math.random().toString(36).slice(2, 8).toUpperCase();

  try {

    let image = new Jimp(225, 50, '#3d3d3d');
    const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
    const w = image.bitmap.width;
    const h = image.bitmap.height;
    const textWidth = Jimp.measureText(font, captcha);
    const textHeight = Jimp.measureTextHeight(font, captcha);

    image.print(font, (w / 2 - textWidth / 2), (h / 2 - textHeight / 2), captcha);
    image.write(`./captchas/${captcha}.png`);

    return captcha;

  } catch (e) {

    console.log(e);

  }
}
class Cleaner {
  constructor(debug) {
    if (typeof debug !== "boolean") {
      throw new Error(
        "Belirttiğiniz debug alma işlemi, boolean (true/false) haricinde bir şey olamaz."
      );
    }

    this.debugBoolean = debug;
  }

  debug(string) {
    try {
      require.resolve("chalk");
      const chalk = require("chalk");

      return console.log(
        `[channelClear] ${chalk.rgb(255, 165, 0)("debug")}: ${chalk.whiteBright(
          string
        )}`
      );
    } catch (e) {
      throw new Error(
        "Debug için gerekli olan 'chalk' modülü bulunamadı. 'npm i chalk' yazarak tekrar deneyin."
      );
    }
  }

  channelClear(client = null, guildID = null, channelObject = null) {
    const debugBoolean = this.debugBoolean,
      debug = this.debug;

    if (debugBoolean) debug("Kanal silme fonksiyonu başlatılıyor!");

    if (
      typeof channelObject !== "object" ||
      !Array.isArray(channelObject) ||
      !channelObject
    ) {
      throw new Error(
        "Kanal silme işlemi için belirtilen obje, bir array değil."
      );
    }

    if (!client || typeof client !== "object") {
      throw new Error("Lütfen discord clientinizi yazmayı unutmayın.");
    }

    if (!guildID || typeof guildID !== "string") {
      throw new Error(
        'Lütfen sunucu IDnizi yazı biçiminde girin. (başına ve sonuna " koyarak)'
      );
    }

    const guild = client.guilds.cache.get(guildID);

    if (!guild) {
      throw new Error(
        `${guildID} IDsi ile belirtilen GUILD (sunucu) bulunamadı. Lütfen düzgün bir sunucu IDsi giriniz.`
      );
    }

    const neededPermissions = [
      "SEND_MESSAGES",
      "MANAGE_CHANNELS",
      "MANAGE_MESSAGES",
    ];

    if (
      !neededPermissions.every((permission) =>
        guild.me.hasPermission(permission)
      )
    ) {
      throw new Error(
        "Belirttiğiniz sunucuda kanal oluşturmak, mesaj yazmak ya da mesajları yönetmek için yetkim yok."
      );
    }

    if (debugBoolean)
      debug(
        `${guild.name} adlı guild, başarıyla bulundu. Şimdi belirttiğiniz sürelere göre loopa sokacağız.`
      );

    /* 
      TODO: Get better solution about array clearing type.
    */

    for (let i = 0; i < channelObject.length; i++) {
      const { channelName, time, channelTopic, afterMessage, afterPin } =
        channelObject[i];
      const channelNumber = i + 1;

      if (!channelName || !time)
        throw new Error("Lütfen kanal ismini ve yenilenme süresini yazın.");

      if (typeof channelName !== "string")
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz kanal ismi, yazı şeklinde yazılmamış.`
        );

      if (typeof time !== "number" || isNaN(time))
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz yenilenme süresi, milisaniye şeklinde yazılmamış.`
        );

      if (channelTopic && typeof channelTopic !== "string")
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz kanal açıklaması, yazı şeklinde yazılmamış.`
        );

      if (afterMessage && typeof afterMessage !== "string")
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz kanal temizlendikten sonraki atılacak mesaj, yazı şeklinde yazılmamış.`
        );

      if (afterPin && !afterMessage)
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz pinleme durumu, kanal silindikten sonra yazılacak bir yazı olmadığından kabul edilemez. Lütfen ya bir yazı ekleyin, ya da bu durumu tersine çevirin.`
        );

      if (afterPin && typeof afterPin !== "boolean")
        throw new Error(
          `${channelNumber}. kanalda belirttiğiniz pinleme durumu, boolean (true/false) şeklinde yazılmamış.`
        );

      // We will create a new Internal for each of channel.
      setInterval(async () => {
        try {
          const channel = guild.channels.cache.find(
            (channel) => channel.name == channelName && channel.type == "text"
          );

          if (!channel) {
            throw new Error(
              `${guild.name} adlı guildde, ${channelName} adında bir kanal bulamadım. Lütfen ismi kontrol eder misiniz?`
            );
          }

          if (debugBoolean)
            debug(
              `${channel.name}: ${channel.name} adlı kanalın bilgileri başarıyla alındı.`
            );

          const { rawPosition, topic } = channel;
          let newChannel;

          if (channelTopic) {
            newChannel = await channel.clone({
              position: rawPosition,
              topic: channelTopic,
            });
          } else {
            newChannel = await channel.clone({ position: rawPosition, topic: topic });
          }

          if (!newChannel)
            throw new Error(
              "Kanal oluşturulurken bir sorun yaşandı. Kanal oluşturma yetkimin olup olmadığına bakar mısınız?"
            );

          if (debugBoolean)
            debug(
              `${channel.name}: Yeni kanal başarıyla oluşturuldu, eski kanal siliniyor.`
            );

          await channel.delete();

          if (debugBoolean)
            debug(
              `${channel.name}: Eski kanal başarıyla silindi. Şimdi atılacak mesaj var mı diye kontrol ediyorum.`
            );

          if (afterMessage) {
            if (debugBoolean)
              debug(
                `${channel.name}: Atılacak bir mesaj buldum, gönderiyorum.`
              );
            let sentMessage = await newChannel.send(afterMessage);
            if (!sentMessage)
              throw new Error(
                "Kanal silinme sonrası mesaj gönderemedim. Yetkilerimi kontrol eder misiniz?"
              );

            if (debugBoolean)
              debug(
                `${channel.name}: Başarıyla mesajı gönderdim, şimdi mesajı pinlemeli miyim diye kontrol ediyorum.`
              );

            if (afterPin) await sentMessage.pin();
          }

          if (debugBoolean)
            debug(
              `${channel.name}: Kontrol edip bana ne söyleniyorsa onu yaptım. İşlem Başarılı.`
            );
        } catch (e) {
          throw new Error(
            `Beklenmedik bir hata aldım: ${e.stack} \n Bu projenin gelişmesinde yardımcı olmak istiyorsan bu hatayı bana proje sayfamın 'Issues' kısmından (https://github.com/vexdy/cleaner/issues) atabilir misin?`
          );
        }
      }, time);
    }
  }
}

module.exports = Cleaner;

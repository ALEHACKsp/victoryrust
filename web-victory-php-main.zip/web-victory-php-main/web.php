<?php

class CWeb
{
    public $arr = [];

    public function output()
    {
        return json_encode($this->arr, true);
    }
}

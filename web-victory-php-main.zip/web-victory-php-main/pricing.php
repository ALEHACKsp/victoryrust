<?php

require_once 'app/require.php';
require_once 'app/controllers/CheatController.php';

$user = new UserController;
$cheat = new CheatController;

Session::init();

//if (!Session::isLogged()) { Util::redirect('/login.php'); }

$username = Session::get("username");
$uid = Session::get("uid");

if (Session::isLogged()) {
	Util::banCheck();
}
Util::head("Show them who you are!");

?>

<body class="bg-white">
	<div class="header-2">

		<?php Util::navbar(); ?>

		<div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
			<div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
				<h1 class="font-bold text-5xl my-4">Pricing</h1>
				<p class="leading-normal">From here, you can find our pricing of our products. <br>To buy, please click on the card for profile login and such.</p>
			</div>
		</div>

		<div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
			<div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
				<h1 class="font-bold text-4xl my-4">Hwid Spoofer</h1>
			</div>
		</div>

		<section class="pt-8 px-4 -mt-16">
			<div class="container mx-auto">
				<div class="flex flex-wrap -mx-4">
					<?php foreach ($user->getPriceList("HWIDSpoofer") as $product) : ?>
						<div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/3 p-4">
							<a href="<?= SITE_URL . "/panel/buy.php" ?>" class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

								<div class="relative pb-48 overflow-hidden">
									<img class="absolute inset-0 h-full w-full object-cover" src="<?= $product->image ?>" alt="">
								</div>

								<div class="p-4">
									<h2 class="mt-2 mb-2 font-bold"><?= $product->product ?> - <?= $product->time ?>
										<?= Util::timeType($product->time_type) ?> </h2>
									<p class="text-sm">This package contains <?= $product->time ?>
										<?= Util::timeType($product->time_type) ?> subscription time for
										<?= $product->product ?> <br>Click the card to buy with instant deliver.</p>
									<div class="mt-3 flex items-center">
										<span class="text-sm font-semibold">only for</span>&nbsp;<span class="font-bold text-xl"><?= $product->price ?> </span>&nbsp;<span class="text-sm font-semibold">€</span>
									</div>
								</div>
							</a>
						</div>
					<?php endforeach; ?>
		</section>


		<div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
			<div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
				<h1 class="font-bold text-4xl my-4">Rust Cheat</h1>
			</div>
		</div>

		<section class="pt-8 px-4 -mt-16">
			<div class="container mx-auto">
				<div class="flex flex-wrap -mx-4">
					<?php foreach ($user->getPriceList("EyePremium") as $product) : ?>
						<div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/3 p-4">
							<a href="<?= SITE_URL . "/panel/buy.php" ?>" class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

								<div class="relative pb-48 overflow-hidden">
									<img class="absolute inset-0 h-full w-full object-cover" src="<?= $product->image ?>" alt="">
								</div>

								<div class="p-4">
									<h2 class="mt-2 mb-2 font-bold"><?= $product->product ?> - <?= $product->time ?> <?= Util::timeType($product->time_type) ?> </h2>
									<p class="text-sm">This package contains <?= $product->time ?> <?= Util::timeType($product->time_type) ?> subscription time for <?= $product->product ?> <br>Click the card to buy with instant deliver.</p>
									<div class="mt-3 flex items-center">
										<span class="text-sm font-semibold">only for</span>&nbsp;<span class="font-bold text-xl"><?= $product->price ?> </span>&nbsp;<span class="text-sm font-semibold">€</span>
									</div>
								</div>
							</a>
						</div>
					<?php endforeach; ?>

					<?php foreach ($user->getPriceList("EyeLegit") as $product) : ?>
						<div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/3 p-4">
							<a href="<?= SITE_URL . "/panel/buy.php" ?>" class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

								<div class="relative pb-48 overflow-hidden">
									<img class="absolute inset-0 h-full w-full object-cover" src="<?= $product->image ?>" alt="">
								</div>

								<div class="p-4">
									<h2 class="mt-2 mb-2 font-bold"><?= $product->product ?> - <?= $product->time ?> <?= Util::timeType($product->time_type) ?> </h2>
									<p class="text-sm">This package contains <?= $product->time ?> <?= Util::timeType($product->time_type) ?> subscription time for <?= $product->product ?> <br>Click the card to buy with instant deliver.</p>
									<div class="mt-3 flex items-center">
										<span class="text-sm font-semibold">only for</span>&nbsp;<span class="font-bold text-xl"><?= $product->price ?> </span>&nbsp;<span class="text-sm font-semibold">€</span>
									</div>
								</div>
							</a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
			<div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
				<h1 class="font-bold text-4xl my-4">Rust Scripts</h1>
			</div>
		</div>

		<section class="pt-8 px-4 -mt-16">
			<div class="container mx-auto">
				<div class="flex flex-wrap -mx-4">

					<?php foreach ($user->getPriceList("vClassic") as $product) : ?>
						<div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/3 p-4">
							<a href="<?= SITE_URL . "/panel/buy.php" ?>" class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

								<div class="relative pb-48 overflow-hidden">
									<img class="absolute inset-0 h-full w-full object-cover" src="<?= $product->image ?>" alt="">
								</div>

								<div class="p-4">
									<h2 class="mt-2 mb-2 font-bold"><?= $product->product ?> - <?= $product->time ?> <?= Util::timeType($product->time_type) ?> </h2>
									<p class="text-sm">This package contains <?= $product->time ?> <?= Util::timeType($product->time_type) ?> subscription time for <?= $product->product ?> <br>Click the card to buy with instant deliver.</p>
									<div class="mt-3 flex items-center">
										<span class="text-sm font-semibold">only for</span>&nbsp;<span class="font-bold text-xl"><?= $product->price ?> </span>&nbsp;<span class="text-sm font-semibold">€</span>
									</div>
								</div>
							</a>
						</div>
					<?php endforeach; ?>

					<?php foreach ($user->getPriceList("vPremium") as $product) : ?>
						<div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/3 p-4">
							<a href="<?= SITE_URL . "/panel/buy.php" ?>" class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

								<div class="relative pb-48 overflow-hidden">
									<img class="absolute inset-0 h-full w-full object-cover" src="<?= $product->image ?>" alt="">
								</div>

								<div class="p-4">
									<h2 class="mt-2 mb-2 font-bold"><?= $product->product ?> - <?= $product->time ?> <?= Util::timeType($product->time_type) ?> </h2>
									<p class="text-sm">This package contains <?= $product->time ?> <?= Util::timeType($product->time_type) ?> subscription time for <?= $product->product ?> <br>Click the card to buy with instant deliver.</p>
									<div class="mt-3 flex items-center">
										<span class="text-sm font-semibold">only for</span>&nbsp;<span class="font-bold text-xl"><?= $product->price ?> </span>&nbsp;<span class="text-sm font-semibold">€</span>
									</div>
								</div>
							</a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<br><br><br><br>
	</div>
	</div>

	<?php Util::second_footer(); ?>
	<script>
		$('.question-and-answer').click(function() {
			$(this).find(".answer").toggleClass("hidden")
			$(this).find(".question-chevron").toggleClass("hidden")
		});
	</script>
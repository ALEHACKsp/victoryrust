<?php

include 'app/require.php';

Session::init();

if (!Session::isLogged()) {
  Util::redirect(SITE_URL . '/login.php');
}

$user = new UserController;
$user->logoutUser();

Util::redirect(SITE_URL);

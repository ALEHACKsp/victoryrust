<?php
require_once 'app/require.php';
$user = new UserController;
echo $user->validateOrder($_POST);

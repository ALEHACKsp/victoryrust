<?php

require_once '../app/require.php';
require_once '../app/controllers/AdminController.php';

$user = new UserController;
$admin = new AdminController;

Session::init();

$username = Session::get("username");

$subList = $admin->getSubCodeArray();

Util::adminCheck();
Util::head('Admin Panel');

// if post request 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {


	if (isset($_POST["genSub"])) {
		$admin->getSubCodeGen($username, $_POST["time"], $_POST["time_type"]);
	}

	header("location: sub.php");

}
?>

<div class="container mt-2">
	<div class="row">

		<?php Util::adminNavbar(); ?>
		<div class="col-12 mb-2 mt-2">
			<table class="rounded table text-black">

				<thead>
					<tr>
						<th scope="col">Code</th>
						<th scope="col">Time</th>
						<th scope="col">Time Type</th>
						<th scope="col">Created By</th>
					</tr>
				</thead>
				<tbody>

					<?php foreach ($subList as $row) : ?>
						<tr>
							<td><?php Util::display($row->code); ?></td>
							<td><?php Util::display($row->time); ?></td>
							<td><?php Util::display($row->time_type); ?></td>
							<td><?php Util::display($row->createdBy); ?></td>
						</tr>
					<?php endforeach; ?>

				</tbody>

			</table>
			<div class="p-3 mb-3">

				<form method="POST">			
                    <input type="number" class="form-control form-control-sm text-black" name="time" placeholder="Time"></input>
                    <input type="hidden" class="form-control" name="class" value="admin"></input>
                    <input type="hidden" class="form-control" name="action" value="getSubCodeGen"></input>
                    <select name="time_type" class="form-control form-control-sm text-black mt-2 mb-2" placeholder="Type">
                        <option value="days">Day</option>
                        <option value="week">Weeks</option>
                        <option value="years">Years</option>
                    </select>
					<button name="genSub" type="submit" class="btn btn-primary">
						Gen Subscription code
					</button>
				</form>

			</div>

		</div>
	</div>

</div>

<?php Util::footer(); ?>
<div class="profile-navbar py-1 px-4 px-md-2 px-lg-4 rounded-0 bg-800 mt-1">
      <div class="p-0">
        <span class="text-white">Admin Panel</span>
        <a href='/admin/index.php' class="btn btn-sm">Ana Sayfa</a>
        <a href='/admin/users.php' class="btn btn-sm">Üyeler</a>
        <a href='/admin/sub.php' class="btn btn-sm">Süre kodları</a>
        <a href='/admin/cheat.php' class="btn btn-sm">Hile Ayarları</a>
    </div>
</div>
<?php

require_once '../app/require.php';
require_once '../app/controllers/AdminController.php';

$user = new UserController;
$admin = new AdminController;

Session::init();

$username = Session::get("username");

$userList = $admin->getUserArray();

Util::adminCheck();
Util::head('Admin Panel');

?>

<div class="container mt-2">
	<div class="row">

		<?php Util::adminNavbar(); ?>

		<div class="col-12 mt-3 mb-2">
			<table class="rounded table">


				<thead>
					<tr class="text-black">

						<th scope="col" class="text-center">UID</th>

						<th scope="col">Kullanıcı İsmi</th>

						<th scope="col">Bakiye</th>

						<th scope="col">Hardware ID</th>

						<th scope="col" class="text-center">Admin mi?</th>

						<th scope="col" class="text-center">Banlanmış mı?</th>

						<th scope="col" class="text-center">Süresi var mı?</th>

						<th scope="col">Aksiyonlar</th>

					</tr>
				</thead>


				<tbody>

					<!--Loop for number of rows-->
					<?php foreach ($userList as $row) : ?>
						<tr class="text-black">
                            <?php $sub = $user->getSubInfo($row->uid); ?>
							<th scope="row" class="text-center"><?php Util::display($row->uid); ?></th>

							<td><?php Util::display($row->username); ?></td>

							<td><?php Util::display($row->balance); ?> ₺</td>

                            <?php if ($sub) : ?>
                            <?php $hwid = strlen($sub->hwid) > 0 ? substr($sub->hwid, 0, 16) . "..." : "Henüz ayarlanmamış."; ?>
                                <td><?php Util::display($hwid); ?></td>
                            <?php else : ?>
                                <td>-</td>
                            <?php endif; ?>

							<td class="text-center">
								<?php if ($row->admin) : ?>
									<i class="fas fa-check-circle"></i>
								<?php else : ?>
									<i class="fas fa-times-circle"></i>
								<?php endif; ?>
							</td>

							<td class="text-center">
								<?php if ($row->banned) : ?>
									<i class="fas fa-check-circle"></i>
								<?php else : ?>
									<i class="fas fa-times-circle"></i>
								<?php endif; ?>
							</td>


                            <td class="text-center">
                                <?php if ($sub) : ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else : ?>
                                    <i class="fas fa-times-circle"></i>
                                <?php endif; ?>
                            </td>

							<td>
								<form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
									<button title="Reset HWID" data-toggle="tooltip" data-placement="top" class="btn btn-sm text-black" type="submit">
										<i class="fas fa-microchip"></i>
									</button>
									<input type="hidden" class="form-control form-control-sm" name="class" value="admin"></input>
									<input type="hidden" class="form-control form-control-sm" value="resetHWID" name="action" ></input>
									<input type="hidden" class="form-control form-control-sm" name="uid" value="<?php Util::display($row->uid); ?>"></input>
								</form>
								<form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
									<button title="Ban/unban user" data-toggle="tooltip" data-placement="top" class="btn btn-sm text-black" type="submit">
										<i class="fas fa-user-slash"></i>
									</button>
									<input type="hidden" class="form-control form-control-sm" name="class" value="admin"></input>
									<input type="hidden" class="form-control form-control-sm" value="setBanned" name="action" ></input>
									<input type="hidden" class="form-control form-control-sm" name="uid" value="<?php Util::display($row->uid); ?>"></input>

								</form>
								<form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
									<button title="Set admin/non admin" data-toggle="tooltip" data-placement="top" class="btn btn-sm text-black" type="submit">
										<i class="fas fa-crown"></i>
									</button>
									<input type="hidden" class="form-control form-control-sm" name="class" value="admin"></input>
									<input type="hidden" class="form-control form-control-sm" value="setAdmin" name="action" ></input>
									<input type="hidden" class="form-control form-control-sm" name="uid" value="<?php Util::display($row->uid); ?>"></input>
								</form>
							</td>

						</tr>
					<?php endforeach; ?>

				</tbody>

			</table>
		</div>
	</div>

</div>
<?php Util::footer(); ?>

<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<?php

require_once 'app/require.php';
require_once 'app/controllers/CheatController.php';

$user = new UserController;
$cheat = new CheatController;

Session::init();

//if (!Session::isLogged()) { Util::redirect('/login.php'); }

$username = Session::get("username");
$uid = Session::get("uid");

if (Session::isLogged()) {
  Util::banCheck();
}
Util::head("Show them who you are!");

?>

<body class="bg-white">
  <div class="header-2">

    <?php Util::navbar(); ?>

    <div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
      <div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
        <h1 class="font-bold text-5xl my-4">Features</h1>
        <p class="leading-normal">Victory is a rust cheat or rust software that you can gain advantages on some games that we are prodiving third party programs and such. In this page, you can see features of our all products.</p>
      </div>
    </div>

    <div class="bg-gray-50 py-6 md:py-12">
      <div class="container px-4 mx-auto">
        <div class="mx-auto text-center px-4 mt-12 text-2xl text-black font-semibold">Unique features</div>

        <div class="md:flex md:flex-wrap md:-mx-4 mt-6 md:mt-12">
          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_2.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Fresh Design</h5>
            <p class="text-gray-600">Victory presents you with a fresh and clean design for better user experience and such. So, you'll not have any problems using Victory!</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_1.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Clean Code</h5>
            <p class="text-gray-600">Victory created with newest technologies which makes your performance ingame better. We use a custom optimization engine to improve your performance.</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_3.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Perfect Tool</h5>
            <p class="text-gray-600">Victory is perfect tool with containing a lot of alternative features and programs that you can choose for your taste.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-indigo-100 py-6 md:py-12 mh-auto">
      <div class="container px-4 mx-auto">
        <div class="text-center max-w-2xl mx-auto">
          <h1 class="text-3xl md:text-4xl font-medium mb-2">Optimization is our priority!</h1>
          <div class="overflow-hidden max-w-full w-full border flex flex-col justify-center items-center">
            We want to ensure that all our users feel with the innovations and performance-enhancing settings we have made, through the programs we have made and in terms of performance. That's why we work by distinguishing between optimization and new feature. We take extra care to ensure that our codes are good at optimizing.
          </div>
        </div>
      </div>
    </div>

    <div class="mx-auto text-center px-4 mt-12 text-2xl text-black font-semibold">Spesific product related features</div>
    <dl class="mt-8 mx-auto flex flex-col mb-16 lg:flex-row lg:flex-wrap">

      <div class="lg:w-1/4">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Basic features & requirements <br>contains all of our products
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <p class="answer hidden mt-2 leading-snug text-gray-700">
            <b>Basic Features:</b> <br>
            - Completely undetected for EAC (Easy AntiCheat) <br>
            - Auto update for every game version <br>
            - Unique build for every user (from our node servers) <br>
            - Polymorphic indicator embedded inside of program <br> <br>

            <b>Requirements:</b> <br>
            - At least a good PC that can open Rust and our product at the same time <br>
            - AMD or Intel Processor <br>
            - Windows 10 with versions of 1509, 1909, 2004, 20H2 and 21H1 (you can check it with command 'winver') <br>
            - Game should run in windowed mode (some users can make it on borderless, you can try) <br>

          </p>
        </div>
      </div>

      <div class="lg:w-1/4">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Feature section about vClassic
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            First to start, this product contains <br>
            our basic features also. <br> <br>

            <b>Features:</b> <br>
            - Recoil Helper (limited on some weapons) <br>
            - Customizable Keybinds for Recoil <br>
            - Works on any sensivity <br>
            - Easy and User-Friendly Interface <br>
            - Personal spray recognition mechanism <br> <br>

            <i>Recommended for legit gameplays</i>

          </dd>
        </div>
      </div>

      <div class="lg:w-1/4">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Feature section about vPremium
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            First to start, this product contains <br>
            our basic features also. <br> <br>

            <b>Features:</b> <br>
            - Recoil Helper <br>
            - Customizable Keybinds for Recoil <br>
            - Works on any sensivity <br>
            - Randomization <br>
            - Sounds on/off <br>
            - Crosshair <br>
            - Hipfire <br>
            - Keybind info menu (ingame) <br>
            - Spotify menu (ingame) <br>
            - Remember me function <br>
            - Weapon preview (ingame) <br>
            - Rapid fire <br>
            - Config system (save/load) <br>
            - Easy and User-Friendly Interface <br>
            - Personal spray recognition mechanism <br>
            - Maximum protection state <br> <br>

            <i>Recommended for more intermediate gameplays</i>

          </dd>
        </div>
      </div>

      <div class="lg:w-1/4">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Feature section about eyePremium
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            First to start, this product contains <br>
            our basic features also. <br> <br>

            <b>Features:</b> <br>
            <i>Visuals:</i> <br>
            - Name ESP <br>
            - Distance ESP <br>
            - Bone ESP <br>
            - Spleepers ESP <br>
            - NPC ESP <br>
            - Health ESP <br>
            - Teammate Check <br>
            - Stash ESP <br>
            - Hemp ESP <br>
            - Node ESP <br>
            - Collactable Node ESP <br>
            - Vehicle ESP <br>
            - Show Weapon <br>
            - Items ESP <br>
            - Show Corpses <br>
            - Flick ESP <br>
            - Show Animals <br>
            - Show Player Info Panel ( Clothes, Weapon, Meds ) <br>
            - Customizable ESP Distance <br> <br>

            <i>Other Features:</i> <br>
            - Aimbot [Mouse5 Button] <br>
            - Aimbot Smoothing [ You can add smooth to aimbot, it makes legit. ] <br>
            - Silent Aimbot [ X key ] - Note: This feature only has an our product on market externally <br>
            - Aimbot FOV <br>
            - Aim Prediction <br>
            - No Recoil <br>
            - No Spread <br>
            - Fast Bullet <br>
            - Fat Bullet <br>
            - Insta Eoka <br>
            - InstaBow <br>
            - Insta Compound <br>
            - Force Full Auto <br>
            - Spiderman <br>
            - Gravity Changer <br>
            - FieldOfView ( FOV ) Changer <br>
            - Admin Flag <br>
            - Always Day <br> <br>

            <i>Recommended for those who want to experience the gameplay at peak</i>
          </dd>
        </div>
      </div>

    </dl>

</body>

<?php Util::second_footer(); ?>
<script>
  $('.question-and-answer').click(function() {
    $(this).find(".answer").toggleClass("hidden")
    $(this).find(".question-chevron").toggleClass("hidden")
  });
</script>
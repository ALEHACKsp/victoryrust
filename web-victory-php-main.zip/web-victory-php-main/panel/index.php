<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
	Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head($username);

?>

<body class="bg-gray-50">

	<div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
		<div class="p-6 border-black">
			<div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
				<div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
					<div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
					<div class="flex flex-row items-end justify-between">
						<span class="text-3xl">Profile</span>
						<a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
					</div>
					<div class="border-t mb-6 mt-1"></div>
					<?php Util::panelNavbar() ?>

					<div class="flex flex-col justify-center items-center">
						<div class="flex flex-col">
							<div class="h-1/3">
								<div class="flex justify-center items-center">
									<span class="text-xl">User Info</span>
								</div>
								<div class="border-t mb-2 mt-2 w-7/8"></div>

								<div class="flex flex-col justify-center items-center ">
									<span class="text-lg">UID: <b><?= $info->uid ?></b></span>
									<span class="text-lg">Balance: <b><?= $info->balance ?><span style="color: forestgreen" class="text-sm font-light">€</span></b></span>
									<span class="text-lg">Username: <b><?= $info->username ?></b></span>
									<span class="text-lg">Email: <b><?= $info->email ?></b></span>
								</div>
							</div>
						</div>
					</div>
					<div class="border-t mt-8"></div>

				</div>
			</div>
		</div>
	</div>
	</div>

	<?php Util::footer(); ?>

<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
  Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
$orders = $user->getUserOrders();
Util::banCheck();
Util::head($username);

?>

<body class="bg-gray-50">

  <div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
    <div class="p-6 border-black">
      <div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
          <div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
          <div class="flex flex-row items-end justify-between">
            <span class="text-3xl">History</span>
            <a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
          </div>
          <div class="border-t mb-6 mt-1"></div>

          <?php Util::panelNavbar() ?>

          <div class="flex flex-col">
            <div class="flex flex-col w-full">
              <div class="h-1/3">
                <div class="flex justify-center items-center">
                  <span class="text-xl">Purchase History</span>
                </div>
                <div class="border-t mb-2 mt-2 w-7/8"></div>
              </div>
              <table class="border rounded-lg">
                <thead class="border rounded-lg">
                  <tr>
                    <th class="ml-2 w-6/12">Purchase Number</th>
                    <th class="border w-3/12">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($orders as $order) : ?>
                    <tr>
                      <th class="border font-light">#<?= $order->slug ?></th>
                      <th class="border font-light"><?= $order->amount ?></th>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>

            </div>
          </div>
          <div class="border-t mb-4 mt-8"></div>

        </div>
      </div>
    </div>
  </div>
  </div>
</body>

<?php Util::footer(); ?>
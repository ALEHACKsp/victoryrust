<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
	Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head($username);

if (!Util::post("amount"))
	Util::redirect("/");

?>

<body class="bg-gray-50">

	<div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
		<div class="p-6 border-black">
			<div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
				<div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
					<div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
					<div class="flex flex-row items-end justify-between">
						<span class="text-3xl">Payment</span>
						<a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
					</div>
					<div class="border-t mb-6 mt-1"></div>
					<div class="-mt-5 mb-8">We are using <b>paym.es</b> solutions for purchases which has 256 SSL protection. We and our payment solution dont<br> save any kind of credentials you give us for payment. So you dont need to get worried about your credentials!</div>

					<div class="flex flex-col justify-center items-center">
						<div class="flex flex-col">
							<div class="h-1/3 -mt-6">
								<div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>

								<div class="flex justify-center items-center">
									<span class="text-xl">Payment Credentials</span>
								</div>
								<div class="border-t mb-6 mt-2 w-7/8 mx-2"></div>
								<form method="POST">
									<div class="mb-4">
										<label class="block text-grey-darker text-sm font-bold mb-2" for="username">
											First Name
										</label>
										<input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" name="firstName" type="text" placeholder="John" required>
									</div>
									<div class="mb-4">
										<label class="block text-grey-darker text-sm font-bold mb-2" for="username">
											Last Name
										</label>
										<input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" name="lastName" type="text" placeholder="Doe" required>
									</div>
									<div class="mb-4">
										<label class="block text-grey-darker text-sm font-bold mb-2" for="password">
											Card Number
										</label>
										<input class="shadow appearance-none border border-red rounded w-full py-2 px-3 text-grey-darker" name="ccNumber" type="tel" pattern="\d*" maxlength="19" placeholder="Card number" required>
									</div>
									<div class="flex justify-around">
										<div class="w:1/2">
											<label class="block text-grey-darker text-sm font-bold mb-2" for="password">
												Expiry Month
											</label>
											<input class="shadow appearance-none border border-red rounded py-2 px-3 text-grey-darker mb-3" name="expiryMonth" type="number" min="1" max="12" placeholder="Month" pattern="\d*" required>
										</div>

										<div class="w:1/2">
											<label class="block text-grey-darker text-sm font-bold mb-2" for="password">
												Expiry Year (20XX)
											</label>
											<input class="shadow appearance-none border border-red rounded py-2 px-3 text-grey-darker mb-3" style="max-width: 150px;" name="expiryYear" type="number" min="<?= date('y') ?>" pattern="\d*" placeholder="Year" required>
										</div>

										<div class="w:1/2 right-0">
											<label class="block text-grey-darker text-sm font-bold mb-2" for="password">
												CVC
											</label>
											<input class="shadow appearance-none border border-red rounded py-2 px-3 text-grey-darker mb-3" style="max-width: 150px;" name="cvv" type="password" maxlength="4" pattern="\d*" placeholder="CVC" required>
										</div>
									</div>
									<div class="flex items-center justify-between mt-3">
										<input type="hidden" name="action" value="createOrder">
										<input type="hidden" name="amount" value="<?= Util::post("amount") ?>">
										<button class="bg-blue-100 w-full hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
											Finish and pay
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="border-t mt-8"></div>

				</div>
			</div>
		</div>
	</div>
	</div>
</body>

<?php Util::footer(); ?>
<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
	Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head($username);

?>

<body class="bg-gray-50">

	<div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
		<div class="p-6 border-black">
			<div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
				<div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
					<div class="opacity-0">
						LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
					<div class="flex flex-row items-end justify-between">
						<span class="text-3xl">Download</span>
						<a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
					</div>
					<div class="border-t mb-6 mt-1"></div>
					<?php Util::panelNavbar() ?>


					<div class="flex flex-col justify-center items-center">
						<div class="flex flex-col">
							<div class="h-1/3">
								<div class="flex justify-center items-center">
									<span class="text-xl">Program</span>
								</div>
								<div class="border-t mb-2 mt-2 w-7/8"></div>

								<div class="flex flex-col justify-center items-center ">
									<span class="text-lg"><b>Download Loader</b></span>
									You can download specified product's loader with clicking on the text!
								</div>
							</div>
							<div class="h-1/3 mt-8">
								<div class="opacity-0">
									LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin
								</div>

								<div class="flex justify-center items-center">
									<span class="text-xl">Expire Info</span>
								</div>
								<div class="border-t mb-6 mt-2 w-7/8 mx-32"></div>

							<form action="/download.php" method="POST" ajax=false>
								<div class="flex flex-row ml-14 mr-8">
									<div class="w-1/3 text-left">
										<p class="leading-none">
											<button name="product" value="vPremium" type="submit" class="hover:text-gray-500 hover:underline text-lg">vPremium Script</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "vPremium"]) ? date('M d Y H:i:s', $sub->vPremium_expire_date) : "Expired"; ?></b>
										</p>
									</div>
									<div class="w-1/3 text-center">
										<p class="leading-none">
											<button name="product" value="vClassic" type="submit" class="hover:text-gray-500 hover:underline text-lg">vClassic Script</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "vClassic"]) ? date('M d Y H:i:s', $sub->vClassic_expire_date) : "Expired!"; ?></b>
										</p>
									</div>
									<div class="w-1/3 text-right">
										<p class="leading-none">
											<button name="product" value="EyeRust" type="submit" class="hover:text-gray-500 hover:underline text-lg">eyePremium Script</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "EyeRust"]) ? date('M d Y H:i:s', $sub->EyeRust_expire_date) : "Expired!"; ?></b>
										</p>
									</div>
								</div>
								<div class="flex flex-row ml-14 mr-8 mt-2">
									<div class="w-1/3 text-left">
										<p class="leading-none">
											<button name="product" value="EyeLegit" type="submit" class="hover:text-gray-500 hover:underline text-lg">eyeLegit Hack</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "EyeLegit"]) ? date('M d Y H:i:s', $sub->EyeLegit_expire_date) : "Expired!"; ?></b>
										</p>
									</div>
									<div class="w-1/3 text-center">
										<p class="leading-none">
											<button name="product" value="HWIDSpoofer" type="submit" class="hover:text-gray-500 hover:underline text-lg">HWID Spoofer</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "HWIDSpoofer"]) ? date('M d Y H:i:s', $sub->HWIDSpoofer_expire_date) : "Expired!"; ?></b>
										</p>
									</div>
									<div class="w-1/3 text-right">
										<p class="leading-none">
											<button name="product" value="EyePremium" type="submit" class="hover:text-gray-500 hover:underline text-lg">eyeRust Hack</button> <br>
											<b class="text-sm"><?= $user->hasActiveSubscription(["uid" => $uid, "product" => "EyePremium"]) ? date('M d Y H:i:s', $sub->EyePremium_expire_date) : "Expired!";  ?></b>
										</p>
									</div>
								</div>
							</div>
						</form>
						</div>
					</div>
					<div class="border-t mb-4 mt-8"></div>

				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
</body>

<?php Util::footer(); ?>
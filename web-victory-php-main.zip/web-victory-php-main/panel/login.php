<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (Session::isLogged()) {
	Util::redirect(SITE_URL . '/panel');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head("Login");

?>

<body class="bg-gray-50">
	<div class="p-12 border-black w-screen h-screen flex flex-row justify-center overflow-hidden">
		<div class="p-6 border-black">
			<div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
				<div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
					<div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
					<div class="flex flex-row items-end justify-between">
						<span class="text-3xl">Login</span>
						<a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
					</div>
					<div class="border-t mb-6 mt-2"></div>
					<form method="POST">
						<div class="mb-4">
							<label class="block text-grey-darker text-sm font-bold mb-2" for="username">
								Username or E-mail
							</label>
							<input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" name="login" type="text" placeholder="Username / E-Mail">
						</div>
						<div class="mb-6">
							<div class="flex items-center justify-between">
								<label class="block text-grey-darker text-sm font-bold mb-2" for="password">
									Password
								</label>
								<!--
							<a href="./register.php"
								class="inline-block align-baseline font-bold text-xs text-gray-400 hover:text-gray-800"
								href="#">
								Forgot your password?
							</a> -->
							</div>
							<input class="shadow appearance-none border border-red rounded w-full py-2 px-3 text-grey-darker mb-3" name="password" type="password" placeholder="Password">
							<input type="hidden" class="form-control" name="action" value="loginUser">
						</div>
						<div class="flex items-center justify-between">
							<button class="bg-blue-100 hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
								Sign In
							</button>
							<a href="./register.php" class="inline-block align-baseline font-bold text-sm text-gray-600 hover:text-gray-800" href="#">
								Don't have an account yet?
							</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>

<?php Util::footer() ?>
<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
  Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head($username);

?>

<body class="bg-gray-50">

  <div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
    <div class="p-6 border-black">
      <div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
          <div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
          <div class="flex flex-row items-end justify-between">
            <span class="text-3xl">Buy</span>
            <a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
          </div>
          <div class="border-t mb-6 mt-1"></div>
          <?php Util::panelNavbar() ?>
          <div class="flex flex-col justify-center items-center">
            <div class="flex flex-col">
              <div class="h-1/3">
                <div class="flex justify-center items-center">
                  <span class="text-xl">Insert Balance</span>
                </div>
                <div class="border-t mb-2 mt-2 w-7/8 mx-16"></div>

                <div class=""> In here, you can select amount of balance and press 'Insert' button to redirect to the payment page.</div>
                <div class="h-1/3 mt-6">
                  <div class="mb-4">
                    <div class="flex flex-row justify-center items-center">
                      <div class="w-2/3 ml-24">
                        <label class="block text-grey-darker text-sm font-bold mb-2" for="amount">
                          Enter balance here
                        </label>
                        <form method="POST" action="./payment.php" ajax=false>
                          <input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" name="amount" type="number" placeholder="Balance" min=1.00 step="0.1">
                      </div>
                      <div class="w-1/3 ml-6 flex flex-row items-start mt-4">
                        <button class="bg-blue-100 hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
                          Insert
                        </button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="h-1/3 mt-2">
                <div class="flex justify-center items-center">
                  <span class="text-xl">Select Package</span>
                </div>
                <div class="border-t mb-2 mt-2 w-7/8 mx-16"></div>

                <div class="flex flex-col justify-center items-center"> After loading the money, you can select a package from here to buy.</div>
                <div class="h-1/3 mt-6">
                  <div class="mb-4">
                    <div class="flex flex-row justify-center items-center">
                      <div class="w-2/3 ml-24">
                        <label class="block text-grey-darker text-sm font-bold mb-2" for="packages">
                          Select a package here
                        </label>
                        <form method="POST">
                          <select id="packages" name="product_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker">
                          <optgroup label = "vClassic">
                          <?php foreach ($user->getPriceList("vClassic") as $item) : ?>
                              <option value="<?= $item->id ?>">
                                <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                            <?php endforeach; ?>
                          </optgroup>
                          
                          <optgroup label = "vPremium">
                          <?php foreach ($user->getPriceList("vPremium") as $item) : ?>
                              <option value="<?= $item->id ?>">
                                <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                            <?php endforeach; ?>
                          </optgroup>

                          <optgroup label = "EyePremium">
                          <?php foreach ($user->getPriceList("EyePremium") as $item) : ?>
                              <option value="<?= $item->id ?>">
                                <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                            <?php endforeach; ?>
                          </optgroup>

                          <optgroup label = "EyeRust">
                          <?php foreach ($user->getPriceList("EyeRust") as $item) : ?>
                              <option value="<?= $item->id ?>">
                                <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                            <?php endforeach; ?>
                          </optgroup>

                          <optgroup label = "EyeLegit">
                          <?php foreach ($user->getPriceList("EyeLegit") as $item) : ?>
                              <option value="<?= $item->id ?>">
                                <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                            <?php endforeach; ?>
                          </optgroup>

                          <optgroup label = "HWIDSpoofer">
                            <?php foreach ($user->getPriceList("HWIDSpoofer") as $item) : ?>
                                <option value="<?= $item->id ?>">
                                  <?= $item->product ?> (<?= $item->time ?> <?= Util::timeType($item->time_type) ?>) - <?= $item->price ?>€</option>
                              <?php endforeach; ?>
                          </optgroup>
                          </select>
                      </div>
                      <div class="w-1/3 ml-6 mt-4">
                        <input type="hidden" name="action" value="buySub">
                        <button class="bg-blue-100 hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
                          Select
                        </button>
                      </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>

              <div class="h-1/3 mt-2">
                <div class="flex justify-center items-center">
                  <span class="text-xl">Activate</span>
                </div>
                <div class="border-t mb-2 mt-2 w-7/8 mx-16"></div>

                <div class="flex flex-col justify-center items-center"> If you have a code to activate your subscription, you can write down here.</div>
                <div class="h-1/3 mt-6">
                  <div class="mb-4">
                    <div class="flex flex-row justify-center items-center">
                      <div class="w-2/3 ml-24">
                        <label class="block text-grey-darker text-sm font-bold mb-2" for="key">
                          Enter your activation code here
                        </label>
                        <form method="POST">
                          <input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" id="key" type="password" name="key" placeholder="Code">
                      </div>
                      <div class="w-1/3 ml-6 mt-4">
                        <input type="hidden" name="action" value="activateSub">
                        <button class="bg-blue-100 hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
                          Activate
                        </button>
                      </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <div class="border-t mb-6 mt-1"></div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</body>

<?php Util::footer(); ?>
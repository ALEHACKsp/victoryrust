<?php

require_once '../app/require.php';

$user = new UserController;

Session::init();

if (!Session::isLogged()) {
  Util::redirect(SITE_URL . '/panel/login.php');
}

$uid = Session::get("uid");
$username = Session::get("username");
$admin = Session::get("admin");

$sub = $user->getSubInfo($uid);
$info = $user->getUserInfo($uid);
Util::banCheck();
Util::head($username);

?>

<body class="bg-gray-50">

  <div class="p-12 border-black w-screen h-screen flex flex-row justify-center">
    <div class="p-6 border-black">
      <div class="p-4 border-black rounded-sm shadow-xl w-full bg-gray-100">
        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 flex flex-col">
          <div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>
          <div class="flex flex-row items-end justify-between">
            <span class="text-3xl">Settings</span>
            <a class="text-xs hover:underline" href="javascript:history.back()">Go back!</a>
          </div>
          <div class="border-t mb-6 mt-1"></div>

          <?php Util::panelNavbar() ?>

          <div class="flex flex-col justify-center items-center">
            <div class="flex flex-col">
              <div class="h-1/3 -mt-6">
                <div class="opacity-0">LoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLoginLogin</div>

                <div class="flex justify-center items-center">
                  <span class="text-xl">Change your password</span>
                </div>
                <div class="border-t mb-6 mt-2 w-7/8 mx-2"></div>
                <form method="POST">
                  <div class="mb-4">
                    <label class="block text-grey-darker text-sm font-bold mb-2" for="username">
                      Old password
                    </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-grey-darker" name="currentPassword" type="password" placeholder="Current Password">
                  </div>
                  <div class="mb-4">
                    <label class="block text-grey-darker text-sm font-bold mb-2" for="password">
                      New password
                    </label>
                    <input class="shadow appearance-none border border-red rounded w-full py-2 px-3 text-grey-darker" name="newPassword" type="password" placeholder="Password">
                  </div>
                  <div class="mb-6">
                    <label class="block text-grey-darker text-sm font-bold mb-2" for="password">
                      New password again
                    </label>
                    <input class="shadow appearance-none border border-red rounded w-full py-2 px-3 text-grey-darker mb-3" name="confirmPassword" type="password" placeholder="Confirm Password">
                  </div>
                  <div class="flex items-center justify-between">
                    <input type="hidden" name="action" value="updateUserPass">
                    <button class="bg-blue-100 hover:bg-blue-300 hover:text-gray-700 text-black font-bold py-2 px-4 rounded" type="submit">
                      Register
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="border-t mt-8"></div>

        </div>
      </div>
    </div>
  </div>
  </div>
</body>

<?php Util::footer(); ?>
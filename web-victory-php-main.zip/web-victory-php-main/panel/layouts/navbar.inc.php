<div class="-mt-5 mb-8"><a href="/panel/" class="<?php if (basename($_SERVER['PHP_SELF']) == 'index.php') echo "font-bold" ?>">Profile</a>
	<span class="invisible">-</span>
	<a href="/panel/buy.php" class="<?php if (basename($_SERVER['PHP_SELF']) == 'buy.php') echo "font-bold" ?>">Buy</a>
	<span class="invisible">-</span>
	<a href="/panel/history.php" class="<?php if (basename($_SERVER['PHP_SELF']) == 'history.php') echo "font-bold" ?>">Purchase History</a>
	<span class="invisible">-</span>
	<a href="/panel/settings.php" class="<?php if (basename($_SERVER['PHP_SELF']) == 'settings.php') echo "font-bold" ?>">Account Settings</a>
	<span class="invisible">-</span>
	<a href="/panel/download.php" class="<?php if (basename($_SERVER['PHP_SELF']) == 'download.php') echo "font-bold" ?>">Download</a>
	<span class="invisible">-</span>
	<a href="/logout.php">Log out</a>
</div>
<?php
header("Content-Type: application/json; charset=UTF-8");

require_once 'app/require.php';
$api = new ApiController;
$api->auth($_POST);

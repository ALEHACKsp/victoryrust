<?php

require_once 'app/require.php';
require_once 'app/controllers/CheatController.php';

$user = new UserController;
$cheat = new CheatController;

Session::init();

if (!Session::isLogged()) {
	Util::redirect('/login.php');
}
Util::banCheck();
$uid = Session::get("uid");
$product = post("product");

if (!$user->hasActiveSubscription(["uid" => $uid, "product" => $product]))
	Util::redirect(SITE_URL);

$info = $user->getUserInfo($uid);
download_file("loaders/$product.exe", $product . ":" . $info->username .  ":" . random_str(10) . ".exe");

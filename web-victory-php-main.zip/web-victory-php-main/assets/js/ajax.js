var url = `${window.location.origin}/api.php`;

$( document ).ready(function() {
    notie.setOptions({
        alertTime: 3,
        dateMonths: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        overlayClickDismiss: true,
        overlayOpacity: 0.75,
        transitionCurve: 'ease',
        transitionDuration: 0.3,
        transitionSelector: 'all',
        classes: {
            container: 'notie-container',
            textbox: 'notie-textbox',
            textboxInner: 'notie-textbox-inner',
            button: 'notie-button',
            element: 'notie-element',
            elementHalf: 'notie-element-half',
            elementThird: 'notie-element-third',
            overlay: 'notie-overlay',
            backgroundSuccess: 'notie-background-success',
            backgroundWarning: 'notie-background-warning',
            backgroundError: 'notie-background-error',
            backgroundInfo: 'notie-background-info',
            backgroundNeutral: 'notie-background-neutral',
            backgroundOverlay: 'notie-background-overlay',
            alert: 'notie-alert',
            inputField: 'notie-input-field',
            selectChoiceRepeated: 'notie-select-choice-repeated',
            dateSelectorInner: 'notie-date-selector-inner',
            dateSelectorUp: 'notie-date-selector-up'
        },
        ids: {
            overlay: 'notie-overlay'
        },
        positions: {
            alert: 'bottom',
            force: 'bottom',
            confirm: 'bottom',
            input: 'bottom',
            select: 'bottom',
            date: 'bottom'
        }
    });

    $("form").submit(function (e) {

            console.log($(this).serialize());

            if(!$(this).attr('ajax'))
                e.preventDefault();

            $.ajax({
                type: $(this).attr('method'),
                async: true,
                url: url,
                data: $(this).serialize(),
                success: function (res) {
                    if(res.message) {
                        notie.force({
                            type: res.type,
                            text: res.message,
                            buttonText: 'OK',
                            callback: function () {

                            }
                        });
                    }

                    if (res.interval) {
                        setTimeout(function () {
                            location.reload();
                        }, res.interval);
                    }

                    if (res.element && res.html)
                        $(res.element).html(res.html);

                    if (res.url)
                        location.href = res.url;
                }
            });
    });
});
<?php
require_once 'app/require.php';

$cheat = new CheatController;

print(json_encode($cheat->getCheatData(), true));

<?php
require_once 'app/require.php';

$api = new ApiController;
$api->downloadCheese($_POST);

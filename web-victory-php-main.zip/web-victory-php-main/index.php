<?php

require_once 'app/require.php';
require_once 'app/controllers/CheatController.php';

$user = new UserController;
$cheat = new CheatController;

Session::init();

//if (!Session::isLogged()) { Util::redirect('/login.php'); }
// test

$username = Session::get("username");
$uid = Session::get("uid");

if (Session::isLogged()) {
  Util::banCheck();
}
Util::head("Show them who you are!");

?>

<body class="bg-white">
  <div class="header-2">
    <?php Util::navbar(); ?>

    <div class="container mx-auto flex flex-col md:flex-row items-center my-12 md:my-24">
      <!--Left Col-->
      <div class="flex flex-col w-full lg:w-1/2 justify-center items-start pt-12 pb-24 px-6">
        <h1 class="font-bold text-5xl my-4">Show them who you are!</h1>
        <p class="leading-normal mb-4">Victory is a team which some of softwares are together that you can gain advantages on some games that softwares are third party programs and such. Undetected till start, still going undetected.</p>
        <a href="<?= SITE_URL . "/pricing.php" ?>" class="bg-transparent hover:bg-gray-900 text-gray-900 hover:text-white rounded shadow hover:shadow-lg py-2 px-4 border border-gray-900 hover:border-transparent">Buy it now!</a>
        <img onclick="location.href='https://discord.gg/mKN7DdpBMt'" src="https://discordapp.com/api/guilds/866750906624507919/widget.png?style=banner2" class="mt-6 overflow-hidden w-72 rounded-sm"></img>
      </div>

      <!--Right Col-->
      <div class="w-full lg:w-1/2 lg:py-6 text-center">
        <!--Add your product image here-->
        <img src="<?= SITE_URL . "/assets/img/mascot.png" ?>" alt="..." class="fill-current text-gray-900 w-3/5 mx-auto">
      </div>
    </div>

    <div class="bg-indigo-100 py-6 md:py-12 mh-auto">
      <div class="container px-4 mx-auto">
        <div class="text-center max-w-2xl mx-auto">
          <h1 class="text-3xl md:text-4xl font-medium mb-2">Watch our trailer on youtube!</h1>
          <div class="overflow-hidden max-w-full w-full border flex flex-col justify-center items-center">
            <iframe width="640" height="315" src="https://www.youtube.com/embed/6N8SJKuBaGw" class="block py-2 px-6 -ml-3 md:ml-5 rounded-sm mt-6 w-full" frameborder="0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-gray-50 py-6 md:py-12">
      <div class="container px-4 mx-auto">
        <div class="md:flex md:flex-wrap md:-mx-4 mt-6 md:mt-12">
          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_2.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Fresh Design</h5>
            <p class="text-gray-600">Victory presents you with a fresh and clean design for better user experience and such. So, you'll not have any problems using Victory!</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_1.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Clean Code</h5>
            <p class="text-gray-600">Victory created with newest technologies which makes your performance ingame better. We use a custom optimization engine to improve your performance.</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/feature_icon_3.png" alt="" class="inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4">Perfect Tool</h5>
            <p class="text-gray-600">Victory is perfect tool with containing a lot of alternative features and programs that you can choose for your taste.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
      <div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
        <h1 class="font-bold text-5xl my-4">Showcase of our products</h1>
        <p class="leading-normal mb-4">Under this text, you should see perfection and hard work. If you dont, please clean your eyes and look at it again. This is what we are prodiving to our precious users.</p>

      </div>

    </div>

    <section class="pt-8 px-4 -mt-16">
      <div class="flex flex-wrap -mx-4">
        <div class="md:w-1/3 px-4 mb-8"><img class="rounded shadow-md" src="<?= SITE_URL . "/assets/img/landing/eyelegit.png" ?>" alt=""></div>
        <div class="md:w-1/3 px-4 mb-8"><img class="rounded shadow-md" src="<?= SITE_URL . "/assets/img/landing/eyerust.png" ?>" alt=""></div>
        <div class="md:w-1/3 px-4 mb-8"><img class="rounded shadow-md" src="<?= SITE_URL . "/assets/img/landing/vpremium.png" ?>" alt=""></div>
      </div>
    </section>

    <div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
      <div class="container px-4 mx-auto">
        <div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
          <h1 class="font-bold text-6xl my-4">Some statistics</h1>
          <p class="leading-normal mb-4">If you are curious :)</p>

        </div>
      </div>

      <div class="py-6 md:py-12">
        <div class="md:flex md:flex-wrap md:-mx-4 mt-6 md:mt-12">
          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/statistic-icon-1.png" alt="" class="h-32 w-32 inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4"> <span class="rounded-full bg-indigo-200 uppercase px-2 py-1 text-xl font-bold mr-3">1200+</span>users</h5>
            <p class="text-gray-600">Our users database is rising and people were selecting us for the first time is always happy about their selections.</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/statistic-icon-2.png" alt="" class="h-32 w-32 inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4"> <span class="rounded-full bg-indigo-200 uppercase px-2 py-1 text-xl font-bold mr-3">%99</span>answer RATIO</h5>
            <p class="text-gray-600">We are making our job seriously and we are making sure all of our users is as good as possible. We are happy about our support.</p>
          </div>

          <div class="md:w-1/3 md:px-4 xl:px-6 mt-8 md:mt-0 text-center">
            <img src="./assets/img/statistic-icon-3.png" alt="" class="h-32 w-32 inline-block mb-3">
            <h5 class="text-xl font-medium uppercase mb-4"> <span class="rounded-full bg-indigo-200 uppercase px-2 py-1 text-xl font-bold mr-3">8</span>softwares</h5>
            <p class="text-gray-600">In Victory, you have so much selection to choose. You can try something, if you dont like it; you can choose another!</p>
          </div>
        </div>
      </div>
    </div>

  </div>

  <div class="bg-indigo-200 text-center py-4 lg:px-4">
    <div class="p-2 bg-indigo-100 items-center text-indigo-400 leading-none lg:rounded-full flex lg:inline-flex" role="alert">
      <span class="flex rounded-full bg-indigo-200 uppercase px-2 py-1 text-xl font-bold mr-3">New</span>
      <span class="font-semibold mr-2 text-left flex-auto text-xl">With our automated balance system, it is easier to buy a product!</span>
      <svg class="fill-current opacity-75 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
        <path d="M12.95 10.707l.707-.707L8 4.343 6.586 5.757 10.828 10l-4.242 4.243L8 15.657l4.95-4.95z" />
      </svg>
    </div>
  </div>
</body>
<?php Util::second_footer(); ?>

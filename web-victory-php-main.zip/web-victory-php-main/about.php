<?php

require_once 'app/require.php';
require_once 'app/controllers/CheatController.php';

$user = new UserController;
$cheat = new CheatController;

Session::init();

//if (!Session::isLogged()) { Util::redirect('/login.php'); }

$username = Session::get("username");
$uid = Session::get("uid");

if (Session::isLogged()) {
  Util::banCheck();
}
Util::head("Show them who you are!");

?>

<body class="bg-white">
  <div class="header-2">
    <?php Util::navbar(); ?>

    <div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24">
      <div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
        <h1 class="font-bold text-5xl my-4">About</h1>
        <p class="leading-normal">In here, you can see more information about the team behind Victory. You can also find our frequently asked questions about team which'll help you meet with us.</p>
      </div>
    </div>

    <div class="container mx-auto flex flex-col md:flex-row justify-center items-center my-12 md:my-24 -mb-12">
      <div class="w-full lg:w-1/2 lg:py-6 text-center" id="pricing">
        <h1 class="font-bold text-5xl my-4">Our precious team</h1>
      </div>

    </div>

    <section class="pt-8 px-4 -mt-16">
      <div class="container mx-auto">
        <div class="flex flex-wrap -mx-4">
          <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/5 p-4">
            <a class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

              <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" src="https://cdn.discordapp.com/avatars/285124795513700352/49e5e0fc28683b8ccc2e70630865dd53.png?size=4096" alt="">
              </div>

              <div class="p-4">
                <h2 class="mt-2 mb-2 font-bold text-2xl">vexdy</h2>
                <p class="text-sm -mt-2 mb-3">web frontend developer</p>
                <p>Cat lover, washedup brain.</p>
              </div>

            </a>
          </div>

          <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/5 p-4">
            <a class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

              <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" src="https://cdn.discordapp.com/avatars/827655989402140773/4b414dfc91aed19fcf67f534faf0db58.png?size=4096" alt="">
              </div>

              <div class="p-4">
                <h2 class="mt-2 mb-2 font-bold text-2xl">alexdelight</h2>
                <p class="text-sm -mt-2 mb-3">web backend developer</p>
                <p>He is obsessive with Thom Yorke</p>
              </div>

            </a>
          </div>

          <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/5 p-4">
            <a class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

              <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" src="https://cdn.discordapp.com/avatars/858772325821186060/625d1c8712f77bececfcefcdb20aeabf.png?size=4096" alt="">
              </div>

              <div class="p-4">
                <h2 class="mt-2 mb-2 font-bold text-2xl">villain</h2>
                <p class="text-sm -mt-2 mb-3">rust ingame developer</p>
                <p>Calm outside, maniac inside.</p>
              </div>

            </a>
          </div>

          <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/5 p-4">
            <a class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

              <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" src="https://cdn.discordapp.com/avatars/572064124406726656/134623b084857867c299eeb09e2670d6.png?size=4096" alt="">
              </div>

              <div class="p-4">
                <h2 class="mt-2 mb-2 font-bold text-2xl">script</h2>
                <p class="text-sm -mt-2 mb-3">rust ingame developer</p>
                <p>Decent boi, cat lover also.</p>
              </div>

            </a>
          </div>

          <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/5 p-4">
            <a class="block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">

              <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" src="https://cdn.discordapp.com/avatars/872454642309668874/f2e442cb8486d1a9289617251468dd5d.png?size=4096" alt="">
              </div>

              <div class="p-4">
                <h2 class="mt-2 mb-2 font-bold text-2xl">vubiu</h2>
                <p class="text-sm -mt-2 mb-3">design & advertisement</p>
                <p>Alcholic interested in crypto.</p>
              </div>

            </a>
          </div>
        </div>
      </div>
    </section>

    <div class="mx-auto text-center px-4 mt-12 text-2xl text-black font-semibold">Product FAQ</div>
    <dl class="mt-8 mx-auto max-w-screen-sm lg:max-w-screen-lg flex flex-col mb-24 lg:flex-row lg:flex-wrap" id="faq">
      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Can I pay with BTC or other crypto currencies?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            You can pay with crypto, ask admin's to get custom buy link.
          </dd>
        </div>
      </div>

      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                How many different computers can I use it on?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            You can only use on 1 PC, cos we has an Hardware ID Licensing system.
          </dd>
        </div>
      </div>

      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Will I get banned if I use the software?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            This is an 3th party software we can't give a promise for that, but we can easily say the most safest products in the market.
          </dd>
        </div>
      </div>

      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Does the script work with all mouses?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            Yes, you can use it on every mouse.
          </dd>
        </div>
      </div>

      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                I have some problems with the program, how can I contact with staff?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            You can use our discord server to contact, for better experience; you can use our direct messages and such.
          </dd>
        </div>
      </div>

      <div class="lg:w-1/3">
        <div class="question-and-answer select-none cursor-pointer border-2 mx-8 my-3 px-6 py-4 rounded-lg text-sm group">
          <dt class="question">
            <div class="flex justify-between">
              <div class="text-indigo-800 font-semibold">
                Where can I talk with other customers?
              </div>
              <div>
                <svg fill=currentColor class="question-chevron group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="9.29289322 12.9497475 10 13.6568542 15.6568542 8 14.2426407 6.58578644 10 10.8284271 5.75735931 6.58578644 4.34314575 8"></polygon>
                    </g>
                  </g>
                </svg>
                <svg fill=currentColor class="question-chevron hidden group-hover:bg-gray-500 h-5 block text-indigo-800 bg-gray-400 rounded-full p-1" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g stroke="currentColor" stroke-width="1" fill=currentColor fill-rule="evenodd">
                    <g>
                      <polygon points="10.7071068 7.05025253 10 6.34314575 4.34314575 12 5.75735931 13.4142136 10 9.17157288 14.2426407 13.4142136 15.6568542 12"></polygon>
                    </g>
                  </g>
                </svg>
              </div>
            </div>
          </dt>
          <dd class="answer hidden mt-2 leading-snug text-gray-700">
            You can join our discord which is on our home page.
          </dd>
        </div>
      </div>
    </dl>
  </div>
</body>

<?php Util::second_footer(); ?>
<script>
  $('.question-and-answer').click(function() {
    $(this).find(".answer").toggleClass("hidden")
    $(this).find(".question-chevron").toggleClass("hidden")
  });
</script>

<?php
header("Content-Type: application/json; charset=UTF-8");

require_once 'app/require.php';
require_once 'web.php';
Session::init();

$user = new UserController;
$admin = new AdminController;
$api = new ApiController;
$web = new CWeb;
$data = $_POST;
$class = isset($data["class"]) ? $data["class"] : $user;
$action = $data["action"];

if ($class == "admin")
    $class = $admin;

if (method_exists($class, $action))
    call_user_func_array([$class, $action], [$data]);


$web->arr = [
    "type" => $user->type,
    "message" => $user->message,
    "interval" => $user->interval,
    "url" => $user->redirect_uri,
    "element" => $user->element,
    "html" => $user->html
];

echo $web->output();

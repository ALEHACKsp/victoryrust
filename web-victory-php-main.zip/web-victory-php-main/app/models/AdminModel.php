<?php

// Extends to class Database
// Only Protected methods
// Only interats with 'Users/Cheat/Invites' tables

// ** Every block should be wrapped in Session::isAdmin(); check **

require_once SITE_ROOT . '/app/core/Database.php';

class Admin extends Database
{

	// Get array of all users 
	// - includes hashed passwords too.
	protected function UserArray()
	{

		if (Session::isAdmin()) {

			$this->prepare('SELECT * FROM `users` ORDER BY uid ASC');
			$this->statement->execute();

			$result = $this->statement->fetchAll();
			return $result;
		}
	}

	// Get array of all subscription codes
	protected function subCodeArray()
	{

		if (Session::isAdmin()) {

			$this->prepare('SELECT * FROM `subscription_keys`');
			$this->statement->execute();

			$result = $this->statement->fetchAll();
			return $result;
		}
	}

	// Create subscription code
	protected function subCodeGen($code, $time, $time_type)
	{

		if (Session::isAdmin()) {
			$createdBy = Session::get("username");
			$this->prepare('INSERT INTO `subscription_keys` (`code`, `createdBy`, `time`, `time_type`) VALUES (?, ?, ?, ?)');
			$this->statement->execute([$code, $createdBy, $time, $time_type]);
		}
	}

	// Resets HWID
	protected function HWID($uid)
	{

		if (Session::isAdmin()) {

			$this->prepare('UPDATE `subscriptions` SET `hwid` = NULL WHERE `uid` = ?');
			$this->statement->execute([$uid]);
		}
	}

	// Set user ban / unban
	protected function banned($uid)
	{

		if (Session::isAdmin()) {

			$this->prepare('SELECT `banned` FROM `users` WHERE `uid` = ?');
			$this->statement->execute([$uid]);
			$result = $this->statement->fetch();
			$ban = $result->banned == true ? false : true;

			$this->prepare('UPDATE `users` SET `banned` = ? WHERE `uid` = ?');
			$this->statement->execute([$ban, $uid]);
		}
	}



	// Set user admin / non admin
	protected function administrator($uid)
	{

		if (Session::isAdmin()) {
			$this->prepare('SELECT `admin` FROM `users` WHERE `uid` = ?');
			$this->statement->execute([$uid]);
			$result = $this->statement->fetch();

			$perm = $result->admin == true ? false : true;

			$this->prepare('UPDATE `users` SET `admin` = ? WHERE `uid` = ?');
			$this->statement->execute([$perm, $uid]);
		}
	}

	protected function cheatStatus()
	{

		if (Session::isAdmin()) {

			$this->prepare('SELECT `status` FROM `cheat`');
			$this->statement->execute();
			$result = $this->statement->fetch();

			$status = $result->status == true ? false : true;

			$this->prepare('UPDATE `cheat` SET `status` = ?');
			$this->statement->execute([$status]);
		}
	}

	protected function cheatMaint()
	{

		if (Session::isAdmin()) {

			$this->prepare('SELECT `maintenance` FROM `cheat`');
			$this->statement->execute();
			$result = $this->statement->fetch();

			$maintenance_status = $result->maintenance == true ? false : true;

			$this->prepare('UPDATE `cheat` SET `maintenance` = ?');
			$this->statement->execute([$maintenance_status]);
		}
	}

	protected function cheatVersion($ver)
	{

		if (Session::isAdmin()) {

			$this->prepare('UPDATE `cheat` SET `version` = ?');
			$this->statement->execute([$ver]);
		}
	}
}

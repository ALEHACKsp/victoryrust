<?php

require_once SITE_ROOT . '/app/core/Database.php';

class Users extends Database
{

	public function getUserArray($data)
	{
		$this->prepare('SELECT * FROM `users` WHERE `uid` = :data OR `username` = :data');
		$this->statement->execute([
			"data" => $data
		]);
		return $this->statement->fetch();
	}

	protected function getSubArray($data)
	{
		$this->prepare('SELECT * FROM `subscriptions` WHERE `uid` = :data OR `hwid` = :data');
		$this->statement->execute(["data" => $data]);
		if ($this->statement->rowCount() > 0)
			return $this->statement->fetch();
		else
			return false;
	}

	protected function insertOrder($data)
	{
		$this->prepare("INSERT INTO orders (uid, firstname, lastname, slug, amount) VALUES (?, ?, ?, ?, ?)");
		return $this->statement->execute([
			$data["uid"],
			$data["firstName"],
			$data["lastName"],
			$data["slug"],
			$data["amount"]
		]);
	}

	protected function getOrderInfo($data)
	{
		$this->prepare("SELECT * FROM orders WHERE slug = ?");
		$this->statement->execute([
			$data["payuPaymentReference"]
		]);

		return $this->statement->fetch();
	}

	protected function completeOrder($data)
	{
		$this->prepare("UPDATE orders SET status = ? WHERE slug = ?");
		return $this->statement->execute([
			1, $data->slug
		]);
	}

	protected function getHasSubscribed($uid)
	{
		$this->prepare('SELECT * FROM `subscriptions` WHERE `uid` = ?');
		$this->statement->execute([$uid]);
		if ($this->statement->rowCount() > 0)
			return true;
		else
			return false;
	}

	protected function getHasActiveSubscribed($data)
	{
		$product = $data["product"] . "_expire_date";
		$this->prepare("SELECT * FROM `subscriptions` WHERE `uid` = :uid && $product > UNIX_TIMESTAMP()");
		$this->statement->execute([
			"uid" => $data["uid"]
		]);
		if ($this->statement->rowCount() > 0)
			return true;
		else
			return false;
	}

	protected function getSubPriceList($product)
	{
		$this->prepare('SELECT * FROM `product_list` WHERE product = :product ORDER BY price ASC');
		$this->statement->execute([
			"product" => $product
		]);
		return $this->statement->fetchAll();
	}

	protected function aGetSubPriceList()
	{
		$this->prepare('SELECT * FROM `product_list`');
		$this->statement->execute();
		return $this->statement->fetchAll();
	}

	// Check if username exists
	protected function usernameCheck($data)
	{

		$this->prepare('SELECT * FROM `users` WHERE `username` = ? OR `email` = ?');
		$this->statement->execute([$data["username"], $data["email"]]);

		if ($this->statement->rowCount() > 0) {
			return true;
		} else {
			return false;
		}
	}

	protected function updateHWID($uid, $new_hwid)
	{
		$this->prepare('UPDATE `subscriptions` SET `hwid` = :hwid WHERE `uid` = :uid');
		return $this->statement->execute([
			"hwid" => $new_hwid,
			"uid" => $uid
		]);
	}

	// Check if sub code is valid
	protected function subCodeCheck($subCode)
	{

		$this->prepare('SELECT * FROM `subscription_keys` WHERE `code` = ?');
		$this->statement->execute([$subCode]);

		if ($this->statement->rowCount() > 0) {
			return true;
		} else {
			return false;
		}
	}

	// Login - Sends data to DB
	protected function login($username, $password)
	{

		// fetch username
		$this->prepare('SELECT * FROM `users` WHERE `username` = :login or `email` = :login');
		$this->statement->execute([
			"login" => $username
		]);
		$row = $this->statement->fetch();

		// If username is correct
		if ($row) {
			$hashedPassword = $row->password;

			// If password is correct
			if (password_verify($password, $hashedPassword)) {
				return $row;
			} else {
				return false;
			}
		}
	}


	// Register - Sends data to DB
	protected function register($username, $email, $hashedPassword)
	{
		// Sending the query - Register user
		$this->prepare('INSERT INTO `users` (`username`, `email`, `password`) VALUES (?, ?, ?)');

		// If user registered
		if ($this->statement->execute([$username, $email, $hashedPassword])) {
			return true;
		} else {
			return false;
		}
	}


	// Update user password
	protected function updatePass($currentPassword, $hashedPassword, $username)
	{
		$this->prepare('SELECT * FROM `users` WHERE `username` = ?');
		$this->statement->execute([$username]);
		$row = $this->statement->fetch();

		// Fetch current password from database
		$currentHashedPassword = $row->password;

		if (password_verify($currentPassword, $currentHashedPassword)) {

			$this->prepare('UPDATE `users` SET `password` = ? WHERE `username` = ?');
			$this->statement->execute([$hashedPassword, $username]);
			return true;
		} else {
			return false;
		}
	}

	protected function addDay($product = null, $uid, $time, $time_type)
	{
		$sub = (array)$this->getSubArray($uid);
		$hasSubscribed = $this->getHasSubscribed($uid);
		$product = "{$product}_expire_date";
		if (!$hasSubscribed) {
			$this->prepare("INSERT INTO `subscriptions` (uid, $product) VALUES (:uid, :time)");
			if ($this->statement->execute([
				"uid" => $uid,
				"time" => strtotime("+$time $time_type", time())
			]))
				return true;
		}
		$sub = $sub[$product] > time() ? $sub[$product] : time();
		$this->prepare("UPDATE `subscriptions` SET $product = :time WHERE uid = :uid");
		if ($this->statement->execute([
			"uid" => $uid,
			"time" => strtotime("+$time $time_type", $sub)
		]))
			return true;

		return false;
	}

	// Activates subscription
	protected function redeemSubscription($subCode, $uid)
	{
		$this->prepare("SELECT * FROM subscription_keys WHERE code = ?");
		$this->statement->execute([$subCode]);
		$row = $this->statement->fetch();

		if ($this->addDay($row->product, $uid, $row->time, $row->time_type)) {
			// Delete the sub code
			$this->prepare('DELETE FROM `subscription_keys` WHERE `code` = ?');
			$this->statement->execute([$subCode]);
			return true;
		} else {
			return false;
		}
	}

	// Get number of users
	protected function userCount()
	{
		$this->prepare('SELECT * FROM `users`');
		$this->statement->execute();
		$result = $this->statement->rowCount();
		return $result;
	}

	// Get number of banned users
	protected function bannedUserCount()
	{
		$this->prepare('SELECT * FROM `users` WHERE `banned` =  1');
		$this->statement->execute();
		$result = $this->statement->rowCount();
		return $result;
	}

	// Get number of users with sub
	protected function activeUserCount()
	{
		$this->prepare('SELECT * FROM `subscriptions` WHERE `expire_date` > UNIX_TIMESTAMP(NOW())');
		$this->statement->execute();
		$result = $this->statement->rowCount();
		return $result;
	}

	protected function userOrders($uid)
	{
		$this->prepare('SELECT * FROM `orders` WHERE `uid` = ? AND status = 1');
		$this->statement->execute([$uid]);
		$result = $this->statement->fetchAll();
		return $result;
	}

	// Get name of latest registered user
	protected function newUser()
	{
		$this->prepare('SELECT `username` FROM `users` WHERE `uid` = (SELECT MAX(`uid`) FROM `users`)');
		$this->statement->execute();
		$result = $this->statement->fetch();
		return $result->username;
	}

	protected function decreaseBalance($uid, $value)
	{
		$this->prepare('UPDATE `users` SET `balance` = ? WHERE uid = ?');
		if ($this->statement->execute([
			floor($this->getUserArray($uid)->balance - $value), $uid
		]))
			return true;

		return false;
	}

	protected function increaseBalance($uid, $value)
	{
		$this->prepare('UPDATE `users` SET `balance` = ? WHERE uid = ?');
		if ($this->statement->execute([
			floor($this->getUserArray($uid)->balance + $value), $uid
		]))
			return true;

		return false;
	}

	protected function getProduct($product_id)
	{
		$this->prepare("SELECT * FROM product_list WHERE id = ?");
		$this->statement->execute([$product_id]);
		return $this->statement->fetch();
	}
}

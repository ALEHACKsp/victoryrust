<?php

require_once SITE_ROOT . "/app/models/UsersModel.php";

class Session
{

	public static function init()
	{

		session_start();
	}


	public static function set($key, $val)
	{

		$_SESSION[$key] = $val;
	}


	public static function get($key)
	{

		return (isset($_SESSION[$key])) ? $_SESSION[$key] : false;
	}


	public static function isLogged()
	{

		return (isset($_SESSION["login"]) && $_SESSION["login"] === true) ? true : false;
	}


	public static function isAdmin()
	{
		$user = new Users;
		$uid = Session::get("uid");
		return $user->getUserArray($uid)->admin;
	}


	public static function isBanned()
	{
		$user = new Users;
		$uid = Session::get("uid");
		return $user->getUserArray($uid)->banned;
	}
}

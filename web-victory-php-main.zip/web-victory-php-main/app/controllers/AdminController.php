<?php

// Extends to class Admin
// Only Public methods

require_once SITE_ROOT . '/app/models/AdminModel.php';
require_once SITE_ROOT . '/web.php';

class AdminController extends Admin
{

	public function getUserArray()
	{
		return $this->UserArray();
	}

	public function getSubCodeArray()
	{
		return $this->subCodeArray();
	}

	public function getSubCodeGen($data)
	{
		$code = Util::randomCode();
		return $this->subCodeGen($code, $data["time"], $data["time_type"]);
	}

	public function resetHWID($data)
	{
		return $this->HWID($data["uid"]);
	}

	public function setBanned($data)
	{
		return $this->banned($data["uid"]);
	}

	public function setAdmin($data)
	{
		return $this->administrator($data["uid"]);
	}

	public function setCheatStatus()
	{
		return $this->cheatStatus();
	}

	public function setCheatMaint()
	{
		return $this->cheatMaint();
	}

	public function setCheatVersion($data)
	{
		return $this->cheatVersion($data);
	}
}

<?php

// Extends to NO classes
// Only Public methods

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class Util
{

    public static function redirect($location)
    {

        header("Location:" . $location);
        exit;
    }


    public static function head($title)
    {

        include(SITE_ROOT . '/includes/head.inc.php');
    }


    public static function navbar()
    {

        include(SITE_ROOT . '/includes/navbar.inc.php');
    }

    public static function panelNavbar()
    {

        include(SITE_ROOT . '/panel/layouts/navbar.inc.php');
    }

    public static function adminNavbar()
    {

        include(SITE_ROOT . '/admin/includes/adminNavbar.inc.php');
    }


    public static function footer()
    {

        include(SITE_ROOT . '/includes/footer.inc.php');
    }

    public static function second_footer()
    {

        include(SITE_ROOT . '/includes/footer2.inc.php');
    }

    public static function display($string)
    {
        echo htmlspecialchars($string);
    }


    // Returns random string
    public static function randomCode()
    {
        $key = "core-" . md5("core" . time() + rand(1, PHP_INT_MAX));
        return $key;
    }

    public static function timeType($type)
    {
        switch ($type) {
            case "second":
            case "seconds":
                $type = "Second";
                break;
            case "hour":
            case "hours":
                $type = "Hour";
                break;
            case "day":
            case "days":
                $type = "Day";
                break;
            case "week":
            case "weeks":
                $type = "Week";
                break;
            case "month":
            case "months":
                $type = "Month";
                break;
            case "year":
            case "years":
                $type  = "Year";
                break;
        }
        return $type;
    }

    // ban check
    public static function banCheck()
    {
        if (Session::isLogged()) {
            // If user is banned
            if (Session::isBanned()) {
                Util::redirect('/logout.php');
            }
        }
    }

    public static function post($par, $st = true)
    {
        if (isset($_POST[$par])) {
            if ($st) {
                return htmlspecialchars(addslashes(trim(strip_tags($_POST[$par]))));
            } else {
                return addslashes(trim(strip_tags($_POST[$par])));
            }
        } else {
            return false;
        }
    }

    public static function sendMail($to, $title, $body){

        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'victoryentertain@gmail.com';                     //SMTP username
            $mail->Password   = 'EXtvrv3ZmdrATHV';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            //Recipients
            $mail->setFrom($mail->Username, SITE_NAME);
            $mail->addAddress($to, '');     //Add a recipient


            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = $title;
            $mail->Body = $body;

            $mail->send();
            return 'Message has been sent';
        } catch (Exception $e) {
            return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }

    // admin check
    public static function adminCheck()
    {

        if (!Session::isAdmin()) {

            Util::redirect('/index.php');
        }
    }
}

<?php

// Extends to class Admin
// Only Public methods

class ApiController extends Users
{
	public function auth($data)
	{
		if ($this->login($data["username"], $data["password"])) {
			$info = $this->getUserArray($data["username"]);
			$sub = (array)$this->getSubArray($info->uid);
			$hwid = $data['hwid'];

			$data["product"] = $data["product"] ?? "vClassic";

			$product = $data["product"] . "_expire_date";

			if ($this->getHasActiveSubscribed([
				"uid" => $sub["uid"],
				"product" => $data["product"]
			])) {
				if ($sub["hwid"] == $hwid) {
					$response = [
						"status" => true,
						"message" => "Logged in successfully!",
						"till" => (int)$sub[$product]
					];
				} else {
					if (empty($sub["hwid"])) {
						if ($this->updateHWID($sub["uid"], $hwid)) {
							$response = [
								"status" => true,
								"message" => "HWID set!"
							];
						}
					} else {
						$response = [
							"status" => false,
							"message" => "HWID mismatched!"
						];
					}
				}
			} else {
				$response = [
					"status" => false,
					"message" => "Your subscription is expired, please buy subscription."
				];
			}
		} else {
			$response = [
				"status" => false,
				"message" => "Your credentials are wrong!"
			];
		}

		print(json_encode($response));
	}
	/*
	public function hwid($data){
			$sub = (array)$this->getSubArray($data["hwid"]);
			$hwid = $data['hwid'];

			if($sub){
				$info = $this->getUserArray($sub["uid"]);
				if($this->getHasActiveSubscribed([
					"uid" => $sub["uid"],
					"product" => $data["product"]
					])){
					$response = [
						"status" => true,
						"message" => "Giriş başarılı.",
						"info" => [
							"username" => $info->username,
							"till" => date("d.m.Y - H:i:s", $sub["{$product}_expire_date"] )
						]
					];
				}
				else{
					$response = [
						"status" => false,
						"message" => "Süreniz bulunmamaktadır."
					];
				}
			}
			else{
				$response = [
					"status" => false,
					"message" => "Böyle bir kullanıcı bulunmamakta."
				];
			}

		print(json_encode($response));
	}

	public function downloadCheese($data){
		if($this->login($data["username"], $data["password"])){
			$info = $this->getUserArray($data["username"]);
			$sub = $this->getSubArray($info->uid);
			$hwid = $data['hwid'];
			if($this->getHasActiveSubscribed([
					"uid" => $sub->uid,
					"product" => $data["product"]
				])){
				if($sub->hwid == $hwid){
					download_file(CHEAT_PATH, "did i asked abisi?");
				}
			}
		}
	}
	*/
}

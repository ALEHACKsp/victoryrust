<?php

// Extends to class Users
// Only Public methods

require_once SITE_ROOT . '/app/models/UsersModel.php';
require_once 'SessionController.php';
require_once 'UtilController.php';
require_once SITE_ROOT . '/app/paymes.php';

class UserController extends Users
{
    public $type = "error";
    public $message;
    public $interval;
    public $redirect_uri;

    public $element;
    public $html;

    public function createUserSession($user)
    {
        Session::set("login", true);
        Session::set("uid", (int)$user->uid);
        Session::set("username", $user->username);
        Session::set("email", $user->email);
    }

    public function logoutUser()
    {
        session_unset();
        $_SESSION = array();
        session_destroy();
    }

    public function createOrder($data)
    {
        $user = $this->getUserInfo(Session::get("uid"));

        $paymes = new paymes(PAYMES_API_SECRET);

        $paymes->setBuyer([
            'id' => 1,
            'billing_firstname' => $data["firstName"],
            'billing_lastname' => $data["lastName"],
            'email' => $user->email
        ]);

        $paymes->setOrderBilling([
            'billing_address' => NULL,
            'billing_city' => NULL,
            'billing_country' => NULL
        ]);

        $paymes->setOrderDelivery([
            'delivery_firstname' => $data["firstName"],
            'delivery_lastname' => $data["lastName"]
        ]);

        $paymes->setOrderPayment([
            'product_name' => 'Balance',
            'card_owner' => $data["firstName"] . $data["lastName"],
            'card_number' => $data["ccNumber"],
            'card_month' => $data["expiryMonth"],
            'card_year' => $data["expiryYear"],
            'card_cvv' => $data["cvv"]
        ]);

        $order = $paymes->run($data["amount"]);

        if ($order["code"] == 200)
            $data["slug"] = $order["payuPaymentReference"];

        $data["uid"] = Session::get("uid");
        //print_r($order);

        $form = $paymes->generateForm($order["paymentResult"]["url"], $data);

        if ($this->insertOrder($data)) {
            $this->element = "body";
            $this->type = "success";
            $this->message = "Payment is processing!";
            $this->html = '
                ' . $form . '
                <script type="text/javascript">
                document.getElementById("payment_form").submit();
                </script>
                ';
        } else {
            $this->message = "Something went wrong during payment!";
        }
    }

    public function validateOrder($data)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://web.paym.es/api/status',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => http_build_query([
            "paymentReference" => $data["payuPaymentReference"]
          ]),
          CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded'
          ],
        ));
        
        $res = curl_exec($curl);        
        curl_close($curl);

        $res = json_decode($res, true);

        if ($res["status"] == 'success') {
            $order = $this->getOrderInfo($data);
            $info = $this->getUserInfo($order->uid);
            if($order->status == 0){
                if($this->completeOrder($order)){
                    $body = file_get_contents("./includes/mail.html");

                    $variables = [
                        "%username%" => $info->username,
                        "%email%" => $order->email,
                        "%AMOUNT%" => $order->amount,
                    ];

                    foreach ($variables as $key => $value)
                        $body = str_replace($key, $value, $body);

                    Util::sendMail($info->email, "Receipt", $body); //sorunlu

                    $this->increaseBalance($order->uid, $order->amount);
                    Util::redirect(SITE_URL . "/panel/");
                } else {
                    return "Contact with staffs!";
                }
            } else {
                return "Something went wrong.";
            }
        } else {
            Util::redirect(SITE_URL);
        }
    }

    public function registerUser($data)
    {
        // Bind login data 
        $username = trim($data['username']);
        $email = trim($data['email']);
        $password = $data['password'];
        $confirmPassword = $data['confirmPassword'];
        //$captcha = $data['g-recaptcha-response'];

        // Empty error vars
        $userError = $passError = "";
        $usernameValidation = "/^[a-zA-Z0-9]*$/";

        /*
        $ip = $_SERVER['REMOTE_ADDR'];
        $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=" . RECAPTCHA_PRIVATE_KEY . "&response=" . $captcha . "&remoteip=" . $ip);
        $response = json_decode($response, true);

        if(!$response["success"]){
            $this->type = "error";
            $this->message = "Robot doğrulamasını yapmadınız, tekrar deneyiniz!";
            $this->interval = 1000;
            return;
        }
*/
        // Validate username on length and letters/numbers
        if (empty($username) || empty($email)) {
            $this->message = "Please fill the username and password field.";
            return;
        } elseif (strlen($username) < 3) {

            $this->message = "Your username is too short.";
            return;
        } elseif (strlen($username) > 25) {

            $this->message = "Your username is too long.";
            return;
        } elseif (!preg_match($usernameValidation, $username)) {

            $this->message = "Your username cannot contain any kind of special characters.";
            return;
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $this->message = "Your e-mail address is not in the right format, it should be like (e.g: hello@victoryrust.com)";
            return;
        } else {

            // Check if username exists
            $userExists = $this->usernameCheck(["username" => $username, "email" => $email]);
            if ($userExists) {
                $this->message = "This username or e-mail is already in use.";
                return;
            }
        }


        // Validate password on length
        if (empty($password)) {

            $this->message = "Fill the password field.";
            return;
        } elseif (strlen($password) < 3) {

            $this->message  = "Your password is too short.";
            return;
        }


        // Validate confirmPassword on length
        if (empty($confirmPassword)) {

            $this->message = "Fill the confirm password field.";
            return;
        } elseif ($password != $confirmPassword) {

            $this->message = "Password and confirm password is mismatched.";
            return;
        }


        // Check if all errors are empty
        if (empty($userError) && empty($passError) && empty($userExistsError)) {

            // Hashing the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $result = $this->register($username, $email, $hashedPassword);

            // Session start
            if ($result) {
                $result = $this->login($username, $password);
                $this->createUserSession($result);

                $this->type = "success";
                $this->message = "Registration is sucessfull!";
                $this->interval = 2000;
                return;
            } else {

                $this->message = 'Something went wrong, keep in contact with staffs.';
                return;
            }
        }
    }

    public function loginUser($data)
    {

        // Bind login data 
        $username = trim($data['login']);
        $password = $data['password'];

        // Validate username
        if (empty($username)) {

            $this->message = "Fill the username field.";
            return;
        }

        // Validate password
        if (empty($password)) {

            $this->message = "Fill the password field.";
            return;
        }

        // Check if all errors are empty
        if (empty($userError) && empty($passError)) {

            $result = $this->login($username, $password);

            if ($result) {

                // Session start
                $this->createUserSession($result);
                $this->type = "success";
                $this->message = "Succesfully logged in!";
                $this->interval = 1000;
            } else {
                $this->message = 'Username or Email is wrong, try again!';
            }
        }
    }


    public function activateSub($data)
    {

        // Bind data
        $uid = Session::get("uid");
        $subCode = $data['key'];

        if (empty($subCode)) {
            $this->message = 'Fill the key field.';
        } else {

            $subCodeExists = $this->subCodeCheck($subCode);

            if ($subCodeExists) {

                if ($this->redeemSubscription($subCode, $uid)) {
                    $this->type = "success";
                    $this->message = "You bought it!";
                } else {
                    $this->message =  "Something went wrong, keep in contact with staffs.";
                }
            } else {

                $this->message = 'There is no any key like that, did you made a typo?';
            }
        }
    }


    public function updateUserPass($data)
    {
        // Bind data
        $username = Session::get("username");
        $currentPassword = $data['currentPassword'];
        $newPassword = $data['newPassword'];
        $confirmPassword = $data['confirmPassword'];


        // Validate password
        if (empty($currentPassword)) {

            $this->message = "Fill the password field.";
            return;
        }

        if (empty($newPassword)) {

            $this->message =  "Fill the password field.";
            return;
        } elseif (strlen($newPassword) < 4) {

            $this->message = "Password is too short.";
            return;
        }


        if (empty($confirmPassword)) {

            $this->message = "Fill the password field.";
            return;
        } elseif ($confirmPassword != $newPassword) {

            $this->message = "Password and new password mismatched.";
            return;
        }


        // Check if all errors are empty
        if (empty($passError)) {

            // Hashing the password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $result = $this->updatePass($currentPassword, $hashedPassword, $username);

            if ($result) {

                $this->type = 'success';
                $this->message = 'Your password is successfully changed!';
                $this->interval = 500;
            } else {

                $this->message = 'Your current password is wrong, try again!';
            }
        }
    }

    public function buySub($data)
    {
        $uid = Session::get("uid");
        $pid = isset($data["product_id"]) ? $data["product_id"] : 1;
        $sub = $this->getProductByPID($pid);
        $user = $this->getUserArray($uid);
        if ($user->balance < $sub->price) {
            $this->message = "Insufficient balance!";
            return;
        }

        if (!$this->decreaseBalance($uid, $sub->price)) {
            $this->message = "Something went wrong!";
            return;
        }

        if (!$this->addDay($sub->product, $uid, $sub->time, $sub->time_type)) {
            $this->message = "Something went wrong.";
        } else {
            $this->type = "success";
            $this->message = "Your days have successfully added to your account!";
        }
    }

    public function getUserCount()
    {
        return $this->userCount();
    }

    public function getBannedUserCount()
    {
        return $this->bannedUserCount();
    }

    public function getActiveUserCount()
    {
        return $this->activeUserCount();
    }

    public function getUserOrders()
    {
        $uid = Session::get("uid");
        return $this->userOrders($uid);
    }

    public function getNewUser()
    {
        return $this->newUser();
    }

    public function getUserInfo($uid)
    {
        return $this->getUserArray($uid);
    }

    public function getSubInfo($uid)
    {
        return $this->getSubArray($uid);
    }

    public function hasSubscription($uid)
    {
        return $this->getHasSubscribed($uid);
    }

    public function hasActiveSubscription($data)
    {
        return $this->getHasActiveSubscribed($data);
    }

    public function getPriceList($product)
    {
        return $this->getSubPriceList($product);
    }

    public function aGetPriceList()
    {
        return $this->aGetSubPriceList();
    }

    public function getProductByPID($product_id)
    {
        return $this->getProduct($product_id);
    }
}

<?php
function random_str(int $length = 64, string $keyspace = '0123456789abcdefghijklmnopqrstuvwxyz'): string
{
    if ($length < 1) {
        throw new RangeException("Length must be a positive integer");
    }
    $pieces = [];
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $pieces[] = $keyspace[random_int(0, $max)];
    }
    return implode('', $pieces);
}

function post($par, $st = true) {
    if (isset($_POST[$par])) {
        if ($st) {
            return htmlspecialchars(addslashes(trim(strip_tags($_POST[$par]))));
        }
        else {
            return addslashes(trim(strip_tags($_POST[$par])));
        }
    }
    else {
        return false;
    }
}

function download_file($file, $download_as)
{
    if (file_exists($file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($download_as) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
}

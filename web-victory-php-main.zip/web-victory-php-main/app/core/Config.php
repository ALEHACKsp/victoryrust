<?php

// SITE PRESETS
define('SITE_ROOT', dirname(__FILE__, 3)); // DO NOT CHANGE
define('SITE_URL', 'http://' . $_SERVER['SERVER_NAME']); // DO NOT CHANGE
date_default_timezone_set("Europe/Istanbul");

// Website Name
define('SITE_NAME', 'VICTORYRUST');

/**
 * Folder name should be defined starting with the "/" (slash)
 * 
 * If you do not plan on having it in a subdomain,
 * keep '' empty without a "/" (slash)
 * example: define('SUB_DIR', '');
 */
define('SUB_DIR', '/');

// Loader link // From Root folder
define('LOADER_URL', SITE_ROOT . '/x.exe');
define('CHEAT_PATH', SITE_ROOT . '/cheese.bin');

define('PAYMES_API_KEY', '5dc3608b-f6dd-4c75-972b-1023cbb270b2'); // Paymes API Key
define('PAYMES_API_SECRET', '725ffcbf27de2c42cc09f0536aaff5fd'); // Paymes API Secret

//Recaptcha
define('RECAPTCHA_SITE_KEY', "6LcTHxEbAAAAAE8KDVo0T4KFvPql03nw1AqAZ0Ai");
define('RECAPTCHA_PRIVATE_KEY', "6LcTHxEbAAAAAFYIxXzKtaf6DMRcwkh7V3AoH0W3");

define('CALLBACK_URL', SITE_URL . "/paymentCallback.php");

// API key
define('API_KEY', 'yes');

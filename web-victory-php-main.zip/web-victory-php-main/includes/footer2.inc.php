<footer class="footer-1 bg-gray-100 py-8 sm:py-12">
  <div class="container mx-auto px-4">
    <div class="sm:flex sm:flex-wrap sm:-mx-4 md:py-4">
      <div class="px-4 sm:w-1/2 md:w-1/4 xl:w-1/6 mt-8 sm:mt-0">
        <h5 class="text-xl font-bold mb-6">Extra Pages</h5>
        <ul class="list-none footer-links">
          <li class="mb-2">
            <a href="/tos.php" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Terms of Service</a>
          </li>
          <li class="mb-2">
            <a href="/tos.php" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Privacy Policy</a>
          </li>
          <li class="mb-2">
            <a href="/about.php" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Frequently Asked Questions</a>
          </li>
        </ul>
      </div>
      <div class="px-4 sm:w-1/2 md:w-1/4 xl:w-1/6 mt-8 md:mt-0">
        <h5 class="text-xl font-bold mb-6">Keywords</h5>
        <ul class="list-none footer-links">
          <li class="mb-2">
            <a href="#" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">HWID Spoofer</a>
          </li>
          <li class="mb-2">
            <a href="#" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Rust</a>
          </li>
          <li class="mb-2">
            <a href="#" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Unban</a>
          </li>
        </ul>
      </div>
      <div class="px-4 sm:w-1/2 md:w-1/4 xl:w-1/6 mt-8 md:mt-0">
        <h5 class="text-xl font-bold mb-6">Help</h5>
        <ul class="list-none footer-links">
          <li class="mb-2">
            <a href="https://discord.gg/mKN7DdpBMt" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Support</a>
          </li>
          <li class="mb-2">
            <a href="https://discord.gg/mKN7DdpBMt" class="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800">Discord</a>
          </li>
        </ul>
      </div>
      <div class="px-4 mt-4 sm:w-1/3 xl:w-1/6 sm:mx-auto xl:mt-0 xl:ml-auto">
        <h5 class="text-xl font-bold mb-6 sm:text-center xl:text-left">Stay connected</h5>
        <div class="flex sm:justify-center xl:justify-start">
          <a href="https://www.elitepvpers.com/">
            <img src="../assets/img/elitepvpers.png"></img>
          </a>

          <!-- <a href="" class="w-8 h-8 border border-2 border-gray-400 rounded-full text-center py-1 text-gray-600 hover:text-white hover:bg-blue-600 hover:border-blue-600">
            <i class="fab fa-facebook"></i>
          </a>
          <a href="" class="w-8 h-8 border border-2 border-gray-400 rounded-full text-center py-1 ml-2 text-gray-600 hover:text-white hover:bg-blue-400 hover:border-blue-400">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="" class="w-8 h-8 border border-2 border-gray-400 rounded-full text-center py-1 ml-2 text-gray-600 hover:text-white hover:bg-red-600 hover:border-red-600">
            <i class="fab fa-google-plus-g"></i>
          </a> -->
        </div>
      </div>
    </div>

    <div class="sm:flex sm:flex-wrap sm:-mx-4 mt-6 pt-6 sm:mt-12 sm:pt-12 border-t">

    </div>

    <div class="text-xs">
      We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with the Rust (Facepunch), or any of its subsidiaries or its affiliates.
    </div>
  </div>
</footer>
<?php Util::footer(); ?>

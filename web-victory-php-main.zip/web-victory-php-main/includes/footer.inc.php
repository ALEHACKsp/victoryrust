<script src="<?= SITE_URL ?>/assets/js/jquery.js"></script>
<script src="<?= SITE_URL ?>/assets/js/ajax.js"></script>
<script src="<?= SITE_URL ?>/assets/js/countdown.js"></script>
<script src="<?= SITE_URL ?>/assets/js/notie.js"></script>

</html>